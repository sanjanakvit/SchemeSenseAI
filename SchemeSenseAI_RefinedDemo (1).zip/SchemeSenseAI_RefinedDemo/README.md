# SchemeSense AI — Demo-ready build

A local Python + Streamlit demo for discovering Indian government programmes, viewing profile-fit recommendations, reading application guidance, ticking a preparation checklist, using a funding planner, and asking SchemeSense AI questions.

## Run in VS Code (Windows)
1. Extract the ZIP and open the `SchemeSenseAI_DemoReady` folder in VS Code.
2. Open Terminal and run:
   ```powershell
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   python -m streamlit run app.py
   ```
3. To stop Streamlit, press `Ctrl+C` in the terminal.

## Demo profile reset
- Use **Demo profile & local data → Start a new demo profile** in the sidebar, or **Clear profile & start again** on My Profile.
- This removes the saved profile, checklist ticks, saved tracker notes and current chat from this local demo database, then opens a blank profile form. This is the intended way to demo a different person. Browser refresh/rerun alone does not erase SQLite data.
- If you need a completely clean demo database while Streamlit is stopped, delete `schemesense.db` from this project folder; it will be recreated on next launch.

## Features
- Saving a profile takes the user directly to **Your Matches**.
- Discover schemes can be filtered by category family (education/scholarships, agriculture/farmers, fisheries/coastal livelihoods, business/self-employment, healthcare/disability, women/family, pensions/social security, housing/services, employment/worker welfare and citizen services), government coverage, catalogue category, purpose and search terms.
- Scheme cards show a neutral government/implementing-department label, a profile-fit percentage, a guide/checklist action and an official starting-source button. These are authority labels, not political-party logos or endorsement.
- Application guide shows a step-by-step route and a resettable preparation checklist. The application-window and progress-tracker section has been removed from this demo build.
- The catalogue does not currently contain verified live deadlines. The app explicitly asks the user to check the latest official notice rather than inventing a date. A verified date can be recorded in the personal tracker.
- The AI page has 16 suggested questions plus a free-text question box. Without an API key it offers a useful topic-specific catalogue-grounded fallback; with `OPENAI_API_KEY`, it uses the OpenAI API for broader conversational answers.
- Funding planner calculates the gap between target and current savings, required monthly amount for the timeline and estimated time at current saving capacity, and lists catalogue leads. It does not invent benefit amounts or assume benefits can be combined.

## Enable broader AI answers (optional)
The app and guided question bank work without an API key, but this fallback is not a general-purpose language model. For broader conversational answers, set your own API key in the same terminal before launching Streamlit:

```powershell
$env:OPENAI_API_KEY="your-key-here"
python -m streamlit run app.py
```

The default model is `gpt-4o-mini`; API use may incur charges. Keep the key private and never put it in source code.

## Important accuracy and privacy notes
- This is a starter catalogue, not a verified real-time government database. The displayed percentage measures catalogue tag alignment, not official eligibility or approval probability.
- Scheme availability, exact eligibility, required documents, benefit amount and application window must be checked on the latest official notice. Some records are umbrella portals, services, registrations, loans or insurance rather than direct cash grants.
- Official labels use a neutral government/department badge. They do not use political party logos or imply endorsement by a politician.
- Profile, checklist and tracker data are stored locally in `schemesense.db` on this computer. Do not enter Aadhaar numbers, OTPs, passwords, full bank details or other unnecessary sensitive information.

## Files
- `app.py` — UI, matching, reset workflow, application guide, tracker, funding planner and AI fallback/API integration
- `data.py` — starter scheme catalogue
- `requirements.txt` — dependencies
- `run_windows.bat` — optional Windows launcher
