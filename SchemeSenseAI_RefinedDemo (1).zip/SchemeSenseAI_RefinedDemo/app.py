import os, sqlite3, re
import streamlit as st
from data import SCHEMES
from collections import defaultdict

def scheme_family(s):
    text=(s.get("name","")+" "+s.get("category","")+" "+s.get("purpose","")+" "+s.get("benefit_type","")+" "+s.get("eligibility","")).lower()
    if any(k in text for k in ("fisheries","fishermen","fisheries welfare","marine fisher","fisher folk")): return "Fisheries & Coastal Livelihoods"
    if any(k in text for k in ("scholarship","education","student","school meal","breakfast scheme","pudhumai penn","tamil pudhalvan")): return "Scholarships & Education"
    if any(k in text for k in ("agriculture","farmer","krishi","soil health","kusum","irrigation","pm-kisan")): return "Agriculture & Farmers"
    if any(k in text for k in ("pension","social security","shram yogi","atal pension","senior citizen")): return "Pensions & Social Security"
    if any(k in text for k in ("health","ayushman","insurance","medicine","poshan","disability","udid")): return "Health & Disability Support"
    if any(k in text for k in ("business","entrepreneur","micro food","credit","loan","industries","self-employed")): return "Business & Self-employment"
    if any(k in text for k in ("women","magalir","family","ujjwala","sukanya")): return "Women & Family"
    if any(k in text for k in ("housing","pmay","sanitation","swachh bharat")): return "Housing & Essential Services"
    if any(k in text for k in ("employment","skill","livelihood","worker","labour","labour welfare","e-shram")): return "Employment & Worker Welfare"
    return "Citizen Services & Other Support"

def government_label(s):
    # Use neutral government/department labels, never a political-party or individual leader logo.
    if s.get("level")=="State" or s.get("state") not in ("All India", ""):
        state=s.get("state") or "State"
        return f"🏛️ {state} Government / Department"
    return "🏛️ Government of India / Implementing Department"

def reset_demo_profile():
    C.execute("DELETE FROM profile"); C.execute("DELETE FROM checklist"); C.execute("DELETE FROM scheme_tracker"); C.commit()
    # Clear Streamlit widget values so the form is genuinely blank on the next run.
    st.session_state.clear()
    st.session_state.page="My profile"
    st.session_state.chat=[]

st.set_page_config(page_title="SchemeSense AI", page_icon="✦", layout="wide")
DB=os.path.join(os.path.dirname(__file__),"schemesense.db")
def conn():
 c=sqlite3.connect(DB,check_same_thread=False); c.row_factory=sqlite3.Row
 c.execute("CREATE TABLE IF NOT EXISTS profile(id INTEGER PRIMARY KEY CHECK(id=1),name TEXT,age INTEGER,state TEXT,district TEXT,education TEXT,occupation TEXT,income REAL,category TEXT,residence TEXT,purpose TEXT,language TEXT,target REAL,notes TEXT)")
 cols={r[1] for r in c.execute('PRAGMA table_info(profile)').fetchall()}
 if 'name' not in cols: c.execute('ALTER TABLE profile ADD COLUMN name TEXT')
 c.execute("CREATE TABLE IF NOT EXISTS checklist(scheme_id TEXT,item TEXT,checked INTEGER DEFAULT 0,PRIMARY KEY(scheme_id,item))")
 c.execute("CREATE TABLE IF NOT EXISTS scheme_tracker(scheme_id TEXT PRIMARY KEY, user_deadline TEXT, status TEXT DEFAULT 'Not started', notes TEXT DEFAULT '')")
 c.commit(); return c
C=conn()
def profile():
 r=C.execute("SELECT * FROM profile WHERE id=1").fetchone(); return dict(r) if r else {}
def save(p):
 keys=["name","age","state","district","education","occupation","income","category","residence","purpose","language","target","notes"]
 values=[p.get(k) for k in keys]
 C.execute("INSERT INTO profile(id,name,age,state,district,education,occupation,income,category,residence,purpose,language,target,notes) VALUES(1,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,age=excluded.age,state=excluded.state,district=excluded.district,education=excluded.education,occupation=excluded.occupation,income=excluded.income,category=excluded.category,residence=excluded.residence,purpose=excluded.purpose,language=excluded.language,target=excluded.target,notes=excluded.notes",values)
 C.commit()
def score(s,p):
 n=0; why=[]
 if not p:return 0,["Complete your profile to personalise recommendations."]
 if s['state']=='All India': n+=1; why.append("National programme listed as available across India; confirm state implementation.")
 elif s['state']==p.get('state'): n+=3; why.append("State matches the programme's listed state.")
 if s['purpose']==p.get('purpose'): n+=4; why.append("Purpose aligns with your stated goal.")
 if s['occupation']==p.get('occupation') or s['occupation']=='Other': n+=2; why.append("Occupation/beneficiary group may be relevant.")
 if s.get('age_min',0) <= int(p.get('age') or 0) <= s.get('age_max',120): n+=1; why.append("Age falls within the catalogue's broad age range; scheme-specific age rules still need checking.")
 if s.get('income_max') is not None and p.get('income') is not None:
  if float(p['income']) <= float(s['income_max']): n+=1; why.append("Recorded household income is within the catalogue's listed ceiling; verify official income definitions and proof.")
  else: why.append("Recorded household income may exceed the catalogue's listed ceiling; verify official rules and exclusions.")
 return n,why
def fit_percentage(s,p):
 """Transparent catalogue-fit indicator, not a probability of approval or eligibility."""
 if not p: return 0
 earned=0.0; possible=80.0  # purpose 35, geography 25, occupation 20
 if s.get('purpose') == p.get('purpose'): earned += 35
 if s.get('state') == p.get('state'): earned += 25
 elif s.get('state') == 'All India': earned += 20
 if s.get('occupation') == p.get('occupation'): earned += 20
 elif s.get('occupation') == 'Other': earned += 12
 age=p.get('age'); age_min=s.get('age_min',0); age_max=s.get('age_max',120)
 # Ignore catalogue-wide default age ranges; only count age when a real bound is recorded.
 if age is not None and (age_min > 0 or age_max < 120):
  possible += 10
  if age_min <= int(age or 0) <= age_max: earned += 10
 if s.get('income_max') is not None and p.get('income') is not None:
  possible += 10
  if float(p['income']) <= float(s['income_max']): earned += 10
 fit=round(earned/possible*100)
 # A state-specific programme outside the user's state cannot score as a strong fit.
 if s.get('state') not in ('All India',p.get('state')): fit=min(fit,25)
 return max(0,min(100,fit))
def status(s,p):
 if not p:return "Complete profile first"
 if s['state'] not in ('All India',p.get('state')):return "State coverage mismatch"
 fit=fit_percentage(s,p)
 if fit>=70:return "Strong profile fit · verify eligibility"
 if fit>=45:return "Possible fit · check conditions"
 return "Needs closer review"
def profile_reasons(s,p):
 if not p: return ["Save your profile to get personalised guidance."]
 reasons=[]
 if s.get('state') == 'All India' or s.get('state') == p.get('state'): reasons.append(f"Geography: {p.get('state')} is compatible with the catalogue coverage (verify the actual rules).")
 if s.get('purpose') == p.get('purpose'): reasons.append(f"Goal: this programme is tagged for {p.get('purpose')}.")
 if s.get('occupation') in (p.get('occupation'), 'Other') or p.get('occupation') == 'Other': reasons.append(f"Beneficiary group: your occupation is {p.get('occupation')} (confirm exact conditions).")
 if p.get('category'): reasons.append(f"Category recorded in your profile: {p.get('category')}; check whether this scheme has a relevant category condition.")
 if p.get('income') is not None: reasons.append("Household income is saved; compare it with any official income ceiling or exclusion rules.")
 return reasons or ["The catalogue has limited matching information. Read the official eligibility notice before proceeding."]

def possible_documents(s,p):
 # These are preparation prompts only, never asserted scheme requirements.
 items=["Official application form / online application details (as specified by the scheme)", "Recent photograph, if requested", "Identity proof accepted by the scheme (check official list)", "Address / residence proof, if required", "Bank account details or passbook, only if the scheme asks for payment details"]
 if p:
  occ=p.get('occupation','')
  if occ=='Student' or p.get('purpose')=='Education and scholarships': items += ["Current admission / bonafide certificate, if required", "Latest marksheet or academic record, if required", "Fee receipt / institution details, if required"]
  if p.get('income') is not None or p.get('purpose') in ('Education and scholarships','Financial assistance','Healthcare'): items.append("Income certificate or accepted income proof, if required")
  if p.get('category') and p.get('category')!='Prefer not to say': items.append(f"{p.get('category')} certificate, only if the official rules request it")
  if occ in ('Farmer','Agricultural worker') or p.get('purpose')=='Agriculture and farming': items += ["Land / cultivation / farmer registration records, only if relevant to this scheme"]
  if occ=='Person with a disability' or p.get('purpose')=='Disability-related assistance': items.append("Disability certificate / UDID, if the scheme requires it")
  if occ in ('Entrepreneur','Self-employed','Artisan') or p.get('purpose')=='Starting or expanding a business': items.append("Business / project / registration documents, if required by the programme or lender")
 # scheme catalogue may contain verified-specific documents in future; current data uses generic placeholders.
 specific=[x for x in s.get('documents',[]) if not x.lower().startswith('check the current official') and not x.lower().startswith('prepare only documents')]
 return list(dict.fromkeys(specific+items+["Official scheme notice saved or bookmarked; current deadline and checklist verified"]))

def application_steps(s,p):
 """Practical route by scheme type; exact steps must still be confirmed in the official notice."""
 name=s.get('name','').lower(); category=s.get('category','').lower(); purpose=s.get('purpose','').lower(); occ=(p or {}).get('occupation','').lower()
 if 'scholarship' in category or 'education' in purpose or 'scholarship' in name or 'pudhumai penn' in name or 'tamil pudhalvan' in name:
  return ["Confirm the exact scholarship/support component, eligible course, academic year and whether your institution is covered.","Check the current notice for marks, attendance, income, category, gender or school-background conditions that apply to this specific programme.","Ask your institution's scholarship/administration office whether it must verify or forward the application; note any institution deadline.","Prepare the exact academic, identity, bank and income/category records named in the official checklist; do not upload extra documents unnecessarily.","Apply on the official scheme/portal within the current window and save the application ID or acknowledgement.","Check whether institution verification, corrections or renewal is required, and monitor the official status until a decision is recorded."]
 if 'loan' in category or 'business' in purpose or occ in ('entrepreneur','self-employed','artisan'):
  return ["Confirm whether the programme offers a loan, subsidy, credit-linked support or service; do not treat a loan as a grant.","Read the current lender/department rules for applicant type, project, contribution, credit assessment, subsidy and repayment obligations.","Prepare a realistic project/business plan and cost estimate if the official route asks for them; do not pay an agent to guarantee approval.","Contact the official portal, participating lender, district industries centre or named implementing agency shown in the notice.","Submit only the requested KYC, business/project and financial documents through the official channel; save the acknowledgement.","Respond to lender/department verification and read the sanction terms, interest, repayment schedule and subsidy conditions before accepting."]
 if 'agriculture' in category or 'agriculture' in purpose or occ in ('farmer','agricultural worker'):
  return ["Identify the exact component, crop/season or agricultural activity and whether it is available in your state/district right now.","Check the current state/district notice for landholding, farmer registration, notified crop/area, season, vendor or other component-specific conditions.","Ask the agriculture office, bank, local implementing agency or official portal named in the notice which route applies to your case.","Prepare farmer/land/crop/bank records only if the official checklist requires them; some services may use existing government records.","Apply or enrol within the official window and keep the application/registration receipt.","Track verification and any inspection, premium/contribution, vendor installation or follow-up that the particular component requires."]
 if 'pension' in category or 'pension' in purpose or 'maandhan' in name:
  return ["Confirm the pension component, minimum/maximum age, income/occupation rules, exclusions and whether contributions are required.","Find the official enrolment route named by the scheme (portal, service centre, bank or local authority) and confirm any fees.","Check the official document list for age, residence, income/occupation and bank/payment details, where applicable.","Complete enrolment only through the official route and save the registration or enrolment number.","If contributory, understand the contribution amount, frequency, missed-payment rules and pension conditions before joining.","Track enrolment status and keep official receipts and scheme communications safely."]
 if 'disability' in category or 'disability' in purpose or 'disability' in occ or 'udid' in name:
  return ["Confirm whether you need a certificate/UDID service or a separate benefit scheme; registration alone may not provide cash assistance.","Check the official portal/medical authority process, accepted disability documentation and any assessment or appointment requirement.","Prepare identity, residence, photograph and medical/disability records only as listed by the official service.","Submit through the official portal or notified authority and save the application number/appointment details.","Attend any required assessment and respond to correction requests through official channels.","After issue, check the separate benefit scheme's eligibility and application process if your goal is financial or educational assistance."]
 if 'health' in purpose or 'healthcare' in category or 'insurance' in category:
  return ["Confirm whether this is health coverage, insurance, a treatment scheme or a service, and check the current beneficiary rules.","Use the official eligibility/beneficiary checker or the department/hospital listed by the scheme, if available.","Check the current list of covered treatment, hospitals, exclusions, limits and any required referral or pre-authorisation.","Carry or upload only the identity, eligibility and medical documents requested by the official provider.","Before treatment or enrolment, ask the authorised hospital/helpline to confirm coverage for the specific service.","Keep the official beneficiary reference, pre-authorisation or claim records and follow the scheme's grievance route if needed."]
 if 'women' in purpose or 'women' in category or 'family' in category:
  return ["Confirm the current programme/component, household conditions, age criteria, exclusions and whether applications are open.","Check the official state/department notice for the authorised application channel and whether existing ration/family records are used.","Prepare the exact residence, household, income or bank evidence listed by the official notice; do not assume all are mandatory.","Apply through the official portal or local authority named in the notice and save the acknowledgement.","Track any field verification, correction request or local-office follow-up using official channels.","Check the official status and grievance process; do not pay anyone who promises guaranteed approval."]
 return ["Open the official starting page and locate the exact scheme/component, responsible department and current application notice.","Check the current eligibility rules, exclusions, benefits, application dates and whether the programme is active in your state/district.","Use the application route named by the official notice (portal, institution, local office, bank or service centre). Avoid unofficial agents.","Compare the official document checklist with your profile and prepare only what is requested.","Complete the application carefully, submit through the official route and save the acknowledgement/reference number.","Track verification and status, respond to corrections before the official deadline, and use the official grievance route if necessary."]

def get_tracker(sid):
 r=C.execute("SELECT * FROM scheme_tracker WHERE scheme_id=?",(sid,)).fetchone()
 return dict(r) if r else {'scheme_id':sid,'user_deadline':'','status':'Not started','notes':''}

def set_tracker(sid,deadline,status_value,notes):
 C.execute("INSERT INTO scheme_tracker(scheme_id,user_deadline,status,notes) VALUES(?,?,?,?) ON CONFLICT(scheme_id) DO UPDATE SET user_deadline=excluded.user_deadline,status=excluded.status,notes=excluded.notes",(sid,deadline,status_value,notes)); C.commit()

def reset_checklist_state(sid, item_count):
 C.execute("DELETE FROM checklist WHERE scheme_id=?", (sid,)); C.commit()
 # Callback runs before Streamlit recreates the widgets, so removing keys is safe.
 for j in range(item_count):
  st.session_state.pop(f"{sid}_{j}", None)
 st.session_state[f"checklist_reset_notice_{sid}"] = True

def card(s,p):
 fit=fit_percentage(s,p)
 st.markdown(f"<div class='authority-badge'>{government_label(s)}</div><div class='scard'><div class='scheme-card-top'><div><span class='pill'>{s['category']}</span><span class='pill'>{s['level']} · {s['state']}</span></div><div class='fit-chip'><strong>{fit}%</strong><span>profile fit</span></div></div><h3>{s['name']}</h3><p>{s['summary']}</p><div class='fit-track'><span style='width:{fit}%'></span></div><div class='fit-caption'>Catalogue fit indicator · not an eligibility or approval probability</div><div class='scheme-meta'><span><b>Support type</b><br>{s['benefit_type']}</span><span><b>Screening</b><br>{status(s,p)}</span></div><p class='muted'>Benefit amount: {s['amount']}</p></div>",unsafe_allow_html=True)
 left,right=st.columns(2)
 with left:
  if st.button("View guide & checklist →",key="open_"+s['id'],type="primary",use_container_width=True): st.session_state.sel=s['id']; st.session_state.page="Scheme guide"; st.rerun()
 with right: st.link_button("Official source ↗",s['url'],use_container_width=True)

def guide(s,p):
 st.title(s['name']); st.write(s['summary'])
 left,right=st.columns([1.15,.85])
 with left:
  st.subheader("Your step-by-step application path")
  steps=application_steps(s,p)
  for i,step in enumerate(steps,1):
   st.markdown(f"<div class='plan-step'><span class='plan-num'>{i:02}</span><div><b>{step}</b></div></div>",unsafe_allow_html=True)
  st.markdown(f"**Implementing authority:** {government_label(s)}")
  st.link_button("Open official scheme / department source ↗", s['url'], use_container_width=True)
  st.caption("This official starting page may be an umbrella portal. Locate the exact scheme component and its latest notice there.")
 with right:
  st.markdown("<div class='gold-panel'><div class='gold-kicker'>YOUR PROFILE REVIEW</div><h3>Why this appeared</h3></div>",unsafe_allow_html=True)
  for reason in profile_reasons(s,p): st.write("• "+reason)
  st.caption("Preliminary matching only — not an official eligibility decision.")
  st.markdown("<div class='gold-panel'><div class='gold-kicker'>DOCUMENT PREPARATION</div><h3>Checklist</h3><p>Tick an item only after checking whether the official notice asks for it.</p></div>",unsafe_allow_html=True)
  items=possible_documents(s,p); done=0
  for i,item in enumerate(items):
   r=C.execute("SELECT checked FROM checklist WHERE scheme_id=? AND item=?",(s['id'],item)).fetchone(); old=bool(r['checked']) if r else False
   new=st.checkbox(item,value=old,key=f"{s['id']}_{i}")
   if new!=old: C.execute("INSERT INTO checklist VALUES(?,?,?) ON CONFLICT(scheme_id,item) DO UPDATE SET checked=excluded.checked",(s['id'],item,int(new))); C.commit()
   done+=int(new)
  st.progress(done/len(items)); st.caption(f"{done}/{len(items)} preparation items checked")
  if done==len(items): st.success("Preparation checklist completed. This does not mean an application was submitted or approved.")
  st.button("Reset checklist",key="reset_"+s['id'], help="Untick every preparation item for this scheme", on_click=reset_checklist_state, args=(s['id'], len(items)))
  if st.session_state.pop(f"checklist_reset_notice_{s['id']}", False):
   st.success("Checklist reset. All items are now unticked.")
 st.markdown("**Benefit:** "+s['benefit_type']+" · **Amount/terms:** "+s['amount'])
 st.markdown("**Eligibility notes from catalogue:** "+s['eligibility'])
 st.caption("Loans need repayment. A service, registration, insurance cover or in-kind benefit is not necessarily cash assistance. The official authority decides eligibility and approval.")

st.markdown("""<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,400,0,0&display=swap');
:root{--ink:#20332f;--muted:#68766f;--cream:#f7f4ed;--paper:#fffdf8;--gold:#b58c48;--forest:#174c43;--line:#e7dfd1}
html,body,[class*='css']{font-family:'DM Sans',sans-serif} span[data-testid='stIconMaterial'],span.material-symbols-rounded{font-family:'Material Symbols Rounded'!important;font-weight:normal!important;font-style:normal!important;font-size:24px!important;line-height:1!important;letter-spacing:normal!important;text-transform:none!important;display:inline-block!important;white-space:nowrap!important;word-wrap:normal!important;direction:ltr!important;font-feature-settings:'liga'!important;-webkit-font-feature-settings:'liga'!important;-webkit-font-smoothing:antialiased!important}.stApp{background:radial-gradient(circle at 88% 0%,#efe5d2 0,transparent 29%),linear-gradient(180deg,#faf8f3 0%,#f3f1eb 100%);color:var(--ink)}
h1,h2,h3{font-family:'Manrope',sans-serif!important;letter-spacing:-.04em;color:#203a33;font-weight:800!important}
[data-testid='stSidebar']{background:linear-gradient(180deg,#102a26 0%,#19443a 58%,#102822 100%);border-right:1px solid rgba(255,255,255,.08)}[data-testid='stSidebar'] *{color:#f8f4e9!important}
[data-testid='stSidebar'] [data-testid='stRadio'] label{padding:10px 12px;border-radius:12px;margin:3px 0;transition:background .2s}[data-testid='stSidebar'] [data-testid='stRadio'] label:hover{background:rgba(255,255,255,.09)}[data-testid='stSidebar'] [data-testid='stRadio'] label p{font-weight:600;font-size:.93rem}
.hero{position:relative;overflow:hidden;padding:43px 42px;border-radius:28px;background:linear-gradient(118deg,#102b27 0%,#1b5147 55%,#3b796a 100%);color:white;margin:4px 0 26px;box-shadow:0 24px 55px rgba(24,61,54,.17);border:1px solid rgba(255,255,255,.12)}
.hero:before{content:'';position:absolute;left:0;top:28px;bottom:28px;width:5px;border-radius:0 8px 8px 0;background:linear-gradient(180deg,#f3d99b,#b58c48)}.hero:after{content:'';position:absolute;right:-76px;top:-116px;width:340px;height:340px;border:1px solid rgba(237,207,151,.48);border-radius:50%;box-shadow:0 0 0 35px rgba(237,207,151,.08),0 0 0 75px rgba(237,207,151,.05),0 0 90px rgba(213,174,100,.13);pointer-events:none}
.hero{padding:50px 48px 46px;background:radial-gradient(ellipse at 86% 18%,rgba(210,171,98,.22),transparent 32%),linear-gradient(118deg,#0b2521 0%,#17483f 52%,#28695a 100%);border:1px solid rgba(221,187,121,.5);box-shadow:0 25px 60px rgba(18,56,48,.23),inset 0 1px 0 rgba(255,255,255,.09)}.hero h1{color:#fff!important;font-size:clamp(2.55rem,4.6vw,3.8rem);line-height:1.02;margin:16px 0 18px;max-width:760px;text-shadow:0 3px 18px rgba(0,0,0,.12)}.hero p{color:#e8f0e9;font-size:1.1rem;max-width:680px;line-height:1.7}.eyebrow{display:inline-block;font-size:.72rem;letter-spacing:.17em;text-transform:uppercase;color:#f0d59b;font-weight:800;background:rgba(201,161,83,.12);border:1px solid rgba(230,196,129,.34);border-radius:999px;padding:8px 12px}
.scard,.panel{background:rgba(255,253,248,.98);border:1px solid var(--line);border-radius:20px;padding:21px 23px;margin:9px 0 15px;box-shadow:0 8px 28px rgba(48,44,35,.045)}.quick-card{position:relative;background:linear-gradient(145deg,#fffefa 0%,#f8f0df 100%);border:1px solid #d9bd80;border-top:3px solid #b58c48;border-radius:19px;padding:20px 18px 17px;min-height:154px;box-shadow:0 10px 28px rgba(100,75,31,.10);transition:transform .2s,box-shadow .2s}.quick-card:hover{transform:translateY(-4px);box-shadow:0 16px 34px rgba(100,75,31,.16)}.quick-icon{display:flex;align-items:center;justify-content:center;width:43px;height:43px;border-radius:14px;background:linear-gradient(135deg,#b58c48,#e2c783);color:#173b32;font-size:1.45rem;font-weight:900;box-shadow:0 5px 12px rgba(181,140,72,.22);margin-bottom:13px}.quick-title{font-family:Manrope,sans-serif;font-size:1rem;font-weight:850;color:#183e34;margin-bottom:6px}.quick-desc{font-size:.83rem;color:#68766f;line-height:1.45}.scard{transition:transform .2s,box-shadow .2s}.scard:hover{transform:translateY(-2px);box-shadow:0 14px 30px rgba(48,44,35,.08)}.scard h3{font-size:1.1rem;margin:.6rem 0}.scard p,.muted{color:var(--muted);font-size:.92rem;line-height:1.6}
.pill{display:inline-block;background:#e7f0eb;color:#245c50;border:1px solid #d4e5dc;border-radius:999px;padding:5px 11px;font-size:.73rem;font-weight:800;margin:0 5px 5px 0}.metric{background:linear-gradient(145deg,#fffdf8,#f7f0e4);border:1px solid #e7dece;border-radius:19px;padding:20px 21px;box-shadow:0 8px 24px rgba(48,44,35,.04)}.num{font-size:1.85rem;font-weight:800;color:#204e45;font-family:'Manrope',sans-serif;margin-top:5px}
.note{background:#fff7e7;border:1px solid #ead8ad;border-radius:15px;padding:15px 17px;color:#715525}div.stButton>button{border-radius:12px;font-weight:750;min-height:2.6rem;border:1px solid #d8d2c7;background:#fffdf8;color:#25453d;transition:all .18s}div.stButton>button:hover{border-color:#b58c48;color:#174c43;box-shadow:0 5px 14px rgba(32,78,69,.08)}div.stButton>button[kind='primary']{background:linear-gradient(135deg,#1b5a4f,#277566);border-color:#1b5a4f;color:white}div.stButton>button[kind='primary']:hover{background:linear-gradient(135deg,#174b42,#1e6256);color:white}
.stTextInput input,.stNumberInput input,.stTextArea textarea{border-radius:11px!important}[data-testid='stExpander']{background:rgba(255,253,248,.9);border:1px solid var(--line);border-radius:14px}[data-testid='stProgressBar']>div>div{background:linear-gradient(90deg,#b58c48,#2b7567)}a{color:#21685c!important;font-weight:700}hr{border-color:#e6dfd3}
footer{visibility:hidden}
/* Let Streamlit render its own Material icons normally; do not suppress icon fonts globally. */
/* Keep hero content within its card at laptop and mobile widths. */
.hero,.hero-copy,.hero-art,.journey-card{box-sizing:border-box;min-width:0;max-width:100%;}
.hero h1{overflow-wrap:anywhere;word-break:normal;}
@media(max-width:900px){.hero{grid-template-columns:minmax(0,1fr)!important}.hero-art{width:100%;overflow:hidden}.hero-copy{width:100%}}


/* Refined Luxe v2: warm editorial styling, richer gold and a clear hero journey */
.hero{display:grid;grid-template-columns:minmax(0,1.22fr) minmax(290px,.78fr);align-items:center;gap:34px;min-height:400px;padding:48px 44px 42px!important;border-radius:30px!important;background:radial-gradient(circle at 80% 20%,rgba(221,185,111,.22),transparent 24%),radial-gradient(circle at 8% 100%,rgba(61,127,105,.25),transparent 32%),linear-gradient(125deg,#0b2420 0%,#123b32 49%,#1e5a4a 100%)!important;border:1px solid rgba(224,190,121,.68)!important;box-shadow:0 26px 64px rgba(18,49,41,.24),inset 0 1px 0 rgba(255,255,255,.12)!important}
.hero:before{left:0;top:34px;bottom:34px;width:5px;background:linear-gradient(180deg,#fff0be,#c79a4b,#f0d79c)!important}
.hero:after{right:30%;top:-165px;width:390px;height:390px;border-color:rgba(230,199,137,.12);box-shadow:0 0 0 38px rgba(230,199,137,.035),0 0 0 78px rgba(230,199,137,.025)!important}
.hero-copy{position:relative;z-index:2}.hero h1{font-size:clamp(2.6rem,4.4vw,4.15rem)!important;line-height:1.02!important;letter-spacing:-.065em!important;margin:20px 0 17px!important}.hero h1 span{color:#e8c77f;text-shadow:0 4px 24px rgba(222,181,98,.13)}.hero p{font-size:1.04rem!important;line-height:1.78!important;color:#e2eee7!important;max-width:580px;margin-bottom:0}.hero-tags{display:flex;flex-wrap:wrap;gap:8px;margin-top:25px}.hero-tags span{display:inline-flex;align-items:center;border:1px solid rgba(230,198,131,.38);background:rgba(255,255,255,.055);padding:9px 12px;border-radius:999px;font-size:.77rem;color:#fff7e6;box-shadow:inset 0 1px 0 rgba(255,255,255,.06)}.hero-tags span:first-child{background:rgba(191,151,72,.13);border-color:rgba(230,198,131,.56)}.hero-foot{margin-top:26px;color:#e3c681;font-size:.66rem;letter-spacing:.13em;font-weight:850;line-height:1.8}.hero-art{position:relative;min-height:310px;display:flex;align-items:center;justify-content:center;isolation:isolate}.orbit{position:absolute;border:1px solid rgba(233,202,140,.27);border-radius:50%;pointer-events:none}.orbit-one{width:340px;height:340px;right:-6px;top:-8px}.orbit-two{width:270px;height:270px;right:29px;top:27px;border-style:dashed;border-color:rgba(233,202,140,.17)}.hero-emblem{position:absolute;right:26px;top:0;display:flex;align-items:center;justify-content:center;width:56px;height:56px;border-radius:19px;background:linear-gradient(145deg,#f4dfa9,#bc9147);color:#173d32;font-size:1.65rem;box-shadow:0 12px 28px rgba(0,0,0,.2),inset 0 1px 0 rgba(255,255,255,.65);transform:rotate(9deg);z-index:2}.journey-card{position:relative;z-index:1;width:min(100%,340px);padding:22px 21px 17px;border:1px solid rgba(240,220,174,.47);border-radius:22px;background:linear-gradient(145deg,rgba(255,253,245,.98),rgba(246,239,220,.97));box-shadow:0 22px 48px rgba(0,0,0,.25),inset 0 1px 0 #fff;transform:rotate(-1deg)}.journey-kicker{font-size:.65rem;letter-spacing:.16em;font-weight:900;color:#9a7334;margin-bottom:17px}.journey-step{display:flex;align-items:center;gap:11px}.journey-num{display:flex;align-items:center;justify-content:center;flex:0 0 35px;height:35px;border-radius:12px;background:linear-gradient(145deg,#d9b66d,#f1dfaa);color:#173e33;font-size:.75rem;font-weight:900;box-shadow:0 4px 10px rgba(172,130,54,.16)}.journey-step b{display:block;font-size:.81rem;color:#203c32;line-height:1.35}.journey-step small{display:block;font-size:.69rem;color:#758078;margin-top:3px}.journey-check{margin-left:auto;color:#99712f;font-weight:900;font-size:1rem}.journey-line{height:17px;border-left:1px dashed #c7b17f;margin:2px 0 2px 17px}.journey-note{display:flex;align-items:center;gap:8px;border-top:1px solid #e8dec8;margin-top:17px;padding-top:13px;color:#6e745f;font-size:.68rem;font-weight:700}.journey-note span{color:#b38a43;font-size:1rem}.hero-seal{position:absolute;z-index:3;left:-10px;bottom:5px;width:83px;height:83px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;background:linear-gradient(145deg,#f6e5b4,#c49a50);color:#163a30;border:5px solid #17463b;box-shadow:0 9px 22px rgba(0,0,0,.2);transform:rotate(-8deg)}.hero-seal span{font-size:.8rem;line-height:1}.hero-seal b{font-family:Manrope,sans-serif;font-size:1.45rem;line-height:1.1}.hero-seal small{text-align:center;font-size:.52rem;line-height:1.1;font-weight:800;text-transform:uppercase;letter-spacing:.05em}
.quick-card{min-height:185px!important;padding:23px 19px 19px!important;border:1px solid #dfc58f!important;border-top:4px solid #b58c48!important;border-radius:21px!important;background:linear-gradient(150deg,#fffefa 0%,#fbf4e5 100%)!important;box-shadow:0 12px 28px rgba(79,61,28,.09),inset 0 1px 0 #fff!important}.quick-icon{width:48px!important;height:48px!important;border-radius:16px!important;background:linear-gradient(145deg,#f1d99a,#b98d43)!important;color:#173d32!important;font-size:1.55rem!important;box-shadow:0 7px 16px rgba(181,140,72,.24),inset 0 1px 0 rgba(255,255,255,.6)!important}.quick-title{font-size:1.02rem!important;letter-spacing:-.025em}.quick-desc{font-size:.84rem!important;min-height:49px}.st-key-quick_Discover\\ schemes button,.st-key-quick_Recommendations button,.st-key-quick_Eligibility\\ checker button,.st-key-quick_Funding\\ calculator button{margin-top:5px}
[data-testid='stVerticalBlock']>div:has(>.quick-card){min-width:0}.stAlert{border-radius:15px;background:#eef4ef!important;border:1px solid #d5e4d8!important;color:#25483f!important}.stAlert svg{color:#3d7967!important;fill:#3d7967!important}[data-testid='stAlert'][kind='error']{background:#f8f0df!important;border-color:#e5d3a7!important;color:#684f25!important}[data-testid='stAlert'][kind='warning']{background:#faf4e7!important;border-color:#e8d6ad!important;color:#6f592c!important}[data-testid='stAlert'][kind='success']{background:#eaf4ed!important;border-color:#cfe3d5!important;color:#285e48!important}.stTabs [data-baseweb='tab-list']{gap:8px}.stTabs [data-baseweb='tab']{border-radius:10px 10px 0 0}.stSelectbox div[data-baseweb='select']>div{border-radius:11px}.stTextInput input:focus,.stNumberInput input:focus,.stTextArea textarea:focus{border-color:#b58c48!important;box-shadow:0 0 0 1px #b58c48!important}
@media(max-width:900px){.hero{grid-template-columns:1fr;gap:20px;padding:34px 25px!important}.hero-art{min-height:300px}.orbit-one{right:calc(50% - 170px)}.orbit-two{right:calc(50% - 135px)}.hero-emblem{right:calc(50% - 155px)}.hero-seal{left:calc(50% - 170px)}.hero h1{font-size:clamp(2.4rem,8vw,3.5rem)!important}}
@media(max-width:600px){.hero{padding:29px 21px!important;border-radius:22px!important}.hero p{font-size:.96rem!important}.hero-tags span{font-size:.7rem;padding:8px 10px}.hero-art{min-height:290px}.journey-card{padding:18px 16px 14px;max-width:310px}.orbit-one{width:300px;height:300px;right:calc(50% - 150px)}.orbit-two{width:240px;height:240px;right:calc(50% - 120px)}.hero-seal{left:calc(50% - 154px);width:72px;height:72px}.hero-seal b{font-size:1.25rem}.hero-emblem{right:calc(50% - 145px);width:48px;height:48px}}



/* Flow redesign: calm ivory, soft sage, forest green and restrained champagne */
:root{--ink:#263b34;--muted:#718078;--cream:#f6f7f2;--paper:#fffefa;--gold:#c5a66b;--forest:#244f43;--line:#e1e7df;--sage:#e7eee6}
html,body,[class*='css']{font-family:'DM Sans',sans-serif} span[data-testid='stIconMaterial'],span.material-symbols-rounded{font-family:'Material Symbols Rounded'!important;font-weight:normal!important;font-style:normal!important;font-size:24px!important;line-height:1!important;letter-spacing:normal!important;text-transform:none!important;display:inline-block!important;white-space:nowrap!important;word-wrap:normal!important;direction:ltr!important;font-feature-settings:'liga'!important;-webkit-font-feature-settings:'liga'!important;-webkit-font-smoothing:antialiased!important}
.stApp{background:radial-gradient(ellipse at 88% 0%,rgba(214,225,207,.58),transparent 30%),linear-gradient(180deg,#f8f8f3 0%,#f2f5ef 100%)!important;color:var(--ink)!important}
h1,h2,h3,h4{font-family:'Manrope',sans-serif!important;letter-spacing:-.04em;color:#29483d!important;font-weight:780!important}
p,li,.stMarkdown,label{color:var(--ink)}
[data-testid='stSidebar']{background:linear-gradient(180deg,#24483e 0%,#2d594b 60%,#23463c 100%)!important;border-right:1px solid rgba(255,255,255,.16)!important}
[data-testid='stSidebar'] *{color:#f6f7ef!important}
[data-testid='stSidebar'] [data-testid='stRadio'] label{padding:10px 12px!important;border-radius:13px!important;margin:4px 0!important;transition:background .22s,transform .22s!important;border:1px solid transparent!important}
[data-testid='stSidebar'] [data-testid='stRadio'] label:hover{background:rgba(255,255,255,.09)!important;transform:translateX(2px)}
[data-testid='stSidebar'] [data-testid='stRadio'] label p{font-size:.92rem!important;font-weight:600!important;letter-spacing:.005em}
[data-testid='stSidebar'] [data-testid='stRadio'] label:has(input:checked){background:rgba(237,243,231,.15)!important;border-color:rgba(220,231,210,.2)!important}
.hero{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(280px,.85fr);align-items:center;gap:28px;position:relative;overflow:hidden;min-height:365px;padding:42px 40px!important;border-radius:28px!important;background:radial-gradient(ellipse at 83% 10%,rgba(215,226,205,.7),transparent 34%),linear-gradient(125deg,#edf2e9 0%,#e4ede3 52%,#d7e5d9 100%)!important;border:1px solid #d6e2d5!important;box-shadow:0 18px 48px rgba(40,76,61,.08),inset 0 1px 0 rgba(255,255,255,.85)!important;color:#29483d!important;margin:4px 0 24px}
.hero:before{left:0;top:30px;bottom:30px;width:4px;background:linear-gradient(180deg,#d5c08e,#b49a61)!important;opacity:.85}
.hero:after{right:27%;top:-170px;width:390px;height:390px;border-color:rgba(86,124,97,.14)!important;box-shadow:0 0 0 38px rgba(86,124,97,.045),0 0 0 78px rgba(86,124,97,.03)!important}
.hero-copy{position:relative;z-index:2}.hero h1{font-size:clamp(2.55rem,4.4vw,4rem)!important;line-height:1.04!important;letter-spacing:-.065em!important;margin:18px 0 16px!important;color:#23463a!important;text-shadow:none!important}.hero h1 span{color:#567a62!important;text-shadow:none!important}.hero p{font-size:1.03rem!important;line-height:1.75!important;color:#53695d!important;max-width:580px;margin-bottom:0}
.eyebrow{display:inline-block;font-size:.69rem;letter-spacing:.14em;text-transform:uppercase;color:#647f66!important;font-weight:800;background:rgba(255,255,255,.55)!important;border:1px solid rgba(137,163,132,.32)!important;border-radius:999px;padding:8px 12px}
.hero-tags{display:flex;flex-wrap:wrap;gap:8px;margin-top:23px}.hero-tags span{display:inline-flex;align-items:center;border:1px solid #d3dfd1!important;background:rgba(255,255,255,.52)!important;padding:8px 11px;border-radius:999px;font-size:.75rem;color:#496451!important;box-shadow:none!important}.hero-tags span:first-child{background:#f8faf5!important;border-color:#cbd9c8!important}.hero-foot{margin-top:23px;color:#7b805f!important;font-size:.65rem;letter-spacing:.12em;font-weight:800;line-height:1.8}
.hero-art{position:relative;min-height:285px;display:flex;align-items:center;justify-content:center;isolation:isolate}.orbit{position:absolute;border:1px solid rgba(93,130,99,.19)!important;border-radius:50%;pointer-events:none}.orbit-one{width:320px;height:320px;right:-5px;top:-15px}.orbit-two{width:250px;height:250px;right:30px;top:20px;border-style:dashed!important;border-color:rgba(93,130,99,.15)!important}.hero-emblem{position:absolute;right:25px;top:0;display:flex;align-items:center;justify-content:center;width:50px;height:50px;border-radius:17px;background:linear-gradient(145deg,#e4d6ae,#c9b47d)!important;color:#345440!important;font-size:1.45rem;box-shadow:0 8px 20px rgba(72,94,66,.12)!important;transform:rotate(7deg);z-index:2}.journey-card{position:relative;z-index:1;width:min(100%,330px);padding:21px 20px 16px;border:1px solid rgba(205,218,199,.9)!important;border-radius:21px!important;background:rgba(255,255,251,.93)!important;box-shadow:0 18px 40px rgba(47,78,56,.12),inset 0 1px 0 #fff!important;transform:none!important}.journey-kicker{font-size:.63rem;letter-spacing:.14em;font-weight:900;color:#8b805d!important;margin-bottom:16px}.journey-step{display:flex;align-items:center;gap:11px}.journey-num{display:flex;align-items:center;justify-content:center;flex:0 0 34px;height:34px;border-radius:12px;background:#e7eee3!important;color:#4c7056!important;font-size:.74rem;font-weight:900;box-shadow:none!important}.journey-step b{display:block;font-size:.81rem;color:#29483d!important;line-height:1.35}.journey-step small{display:block;font-size:.68rem;color:#7b897f!important;margin-top:3px}.journey-check{margin-left:auto;color:#82956d!important;font-weight:900;font-size:1rem}.journey-line{height:16px;border-left:1px dashed #cbd7c6!important;margin:2px 0 2px 16px}.journey-note{display:flex;align-items:center;gap:8px;border-top:1px solid #e7ece3!important;margin-top:16px;padding-top:12px;color:#778272!important;font-size:.67rem;font-weight:700}.journey-note span{color:#b19a63!important;font-size:1rem}.hero-seal{position:absolute;z-index:3;left:-9px;bottom:0;width:76px;height:76px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;background:linear-gradient(145deg,#e6ddbd,#c8bb91)!important;color:#345440!important;border:4px solid #e3ede0!important;box-shadow:0 8px 18px rgba(45,75,54,.12)!important;transform:none!important}.hero-seal span{font-size:.7rem;line-height:1}.hero-seal b{font-family:Manrope,sans-serif;font-size:1.35rem;line-height:1.1}.hero-seal small{text-align:center;font-size:.48rem;line-height:1.1;font-weight:800;text-transform:uppercase;letter-spacing:.05em}
.scard,.panel{background:rgba(255,255,251,.86)!important;border:1px solid #e1e8de!important;border-radius:20px!important;padding:21px 23px!important;margin:9px 0 15px!important;box-shadow:0 7px 24px rgba(42,72,50,.035)!important}.scard{transition:transform .22s,box-shadow .22s,border-color .22s!important}.scard:hover{transform:translateY(-2px);box-shadow:0 13px 28px rgba(42,72,50,.07)!important;border-color:#d0dfce!important}.scard h3{font-size:1.1rem;margin:.6rem 0;color:#29483d!important}.scard p,.muted{color:#718078!important;font-size:.92rem;line-height:1.65}
.quick-card{position:relative;background:linear-gradient(145deg,#fffefa 0%,#f0f5ed 100%)!important;border:1px solid #dce6d9!important;border-bottom:0!important;border-radius:18px 18px 0 0!important;padding:20px 18px 15px!important;min-height:164px!important;box-shadow:0 7px 20px rgba(45,76,53,.045)!important;transition:transform .22s,box-shadow .22s!important}.quick-card:hover{transform:translateY(-2px);box-shadow:0 12px 25px rgba(45,76,53,.075)!important}.quick-icon{display:flex;align-items:center;justify-content:center;width:42px!important;height:42px!important;border-radius:14px!important;background:#e3ecdf!important;color:#4c7056!important;font-size:1.35rem!important;font-weight:800!important;box-shadow:none!important;margin-bottom:12px}.quick-title{font-family:Manrope,sans-serif;font-size:1rem!important;font-weight:800!important;color:#29483d!important;margin-bottom:6px}.quick-desc{font-size:.82rem!important;color:#718078!important;line-height:1.5!important;min-height:45px}
div[class*='st-key-quick_']{margin-top:-1px!important}div[class*='st-key-quick_'] button{border-radius:0 0 17px 17px!important;border-top:1px solid #dce6d9!important;background:#f0f5ed!important;color:#4a6b53!important;font-weight:750!important;min-height:2.45rem!important;box-shadow:0 7px 20px rgba(45,76,53,.035)!important}div[class*='st-key-quick_'] button:hover{background:#e7efe3!important;border-color:#c7d8c4!important;color:#29483d!important;transform:translateY(-1px)}
.metric{background:linear-gradient(145deg,#fffefa,#f0f5ed)!important;border:1px solid #e0e8dc!important;border-radius:18px!important;padding:20px 21px!important;box-shadow:0 7px 22px rgba(42,72,50,.035)!important}.num{font-size:1.85rem;font-weight:800;color:#3e6b4c!important;font-family:'Manrope',sans-serif;margin-top:5px}
.pill{display:inline-block;background:#e8f0e5!important;color:#496e51!important;border:1px solid #d8e5d4!important;border-radius:999px;padding:5px 11px;font-size:.73rem;font-weight:800;margin:0 5px 5px 0}.note{background:#f1f4e9!important;border:1px solid #dfe7d5!important;border-radius:15px;padding:15px 17px;color:#536a51!important}
div.stButton>button{border-radius:13px!important;font-weight:700!important;min-height:2.65rem!important;border:1px solid #dce5d8!important;background:#fffefa!important;color:#3f6249!important;transition:all .2s ease!important;box-shadow:0 3px 10px rgba(42,72,50,.025)!important}div.stButton>button:hover{border-color:#bdcfb8!important;background:#f4f7f0!important;color:#29483d!important;box-shadow:0 6px 15px rgba(42,72,50,.06)!important;transform:translateY(-1px)}div.stButton>button[kind='primary']{background:linear-gradient(135deg,#456e51,#5b8062)!important;border-color:#456e51!important;color:#fff!important;box-shadow:0 6px 16px rgba(54,94,62,.14)!important}div.stButton>button[kind='primary']:hover{background:linear-gradient(135deg,#3d6248,#507657)!important;color:#fff!important}
.stTextInput input,.stNumberInput input,.stTextArea textarea,[data-baseweb='select']>div{border-radius:12px!important;background:#fffefa!important;border-color:#dce5d8!important;color:#29483d!important}.stTextInput input:focus,.stNumberInput input:focus,.stTextArea textarea:focus{border-color:#8eae8d!important;box-shadow:0 0 0 2px rgba(137,169,132,.13)!important}[data-testid='stExpander']{background:rgba(255,255,251,.8)!important;border:1px solid #e0e8dc!important;border-radius:15px!important}[data-testid='stProgressBar']>div>div{background:linear-gradient(90deg,#c6b27b,#719576)!important}a{color:#4d7657!important;font-weight:700!important}hr{border-color:#e1e8de!important}footer{visibility:hidden}
/* Replace harsh red error/warning blocks with calm, readable status surfaces */
[data-testid='stAlert'],.stAlert,[data-baseweb='notification']{background:#f0f4eb!important;border:1px solid #dce6d5!important;border-radius:14px!important;color:#455e49!important;box-shadow:none!important}[data-testid='stAlert'] p,.stAlert p,[data-baseweb='notification'] p{color:#455e49!important}[data-testid='stAlert'] svg,.stAlert svg{color:#78916b!important}
.gold-panel{border:1px solid #d9e4d5!important;border-radius:18px!important;padding:17px 19px!important;background:linear-gradient(145deg,#edf3e9,#e2ecdf)!important;margin:8px 0 12px!important}.gold-kicker{font-size:.66rem;letter-spacing:.14em;font-weight:900;color:#71875f!important;margin-bottom:7px}.gold-panel h3{margin:0;color:#29483d!important}.plan-step{display:flex;align-items:flex-start;gap:13px;padding:14px 15px;border:1px solid #e0e8dc!important;border-radius:15px!important;background:#fffefa!important;margin:8px 0;color:#40584a!important}.plan-step b{font-weight:600;color:#40584a!important;line-height:1.6}.plan-num{display:flex;align-items:center;justify-content:center;flex:0 0 36px;height:36px;border-radius:12px;background:#e3ecdf!important;color:#4b7054!important;font-weight:900;font-size:.78rem}
[data-testid='stAppViewContainer'] .block-container{padding-top:2rem;padding-bottom:3rem;max-width:1380px}
.site-topline{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0 0 20px;padding:0 0 13px;border-bottom:1px solid #e1e8de;color:#829087;font-size:.78rem}.site-topline .crumb{color:#4e7056;font-weight:750}.site-topline .promise{color:#849083}
@media(max-width:900px){.hero{grid-template-columns:1fr!important;padding:34px 28px!important;gap:12px!important}.hero-art{min-height:290px}.orbit-one{right:calc(50% - 160px)}.orbit-two{right:calc(50% - 125px)}.hero-emblem{right:calc(50% - 145px)}.hero-seal{left:calc(50% - 165px)}}
@media(max-width:600px){.hero{padding:27px 20px!important;border-radius:22px!important}.hero h1{font-size:clamp(2.25rem,9vw,3.2rem)!important}.hero p{font-size:.96rem!important}.hero-tags span{font-size:.69rem;padding:7px 9px}.hero-art{min-height:275px}.journey-card{padding:17px 15px 13px;max-width:300px}.orbit-one{width:285px;height:285px;right:calc(50% - 142px)}.orbit-two{width:230px;height:230px;right:calc(50% - 115px)}.hero-seal{left:calc(50% - 150px);width:68px;height:68px}.hero-seal b{font-size:1.15rem}.hero-emblem{right:calc(50% - 137px);width:44px;height:44px}}


/* ELEGANT CONTINUOUS EXPERIENCE — deep teal, pearl, jade and champagne */
:root{--ink:#183c3b;--muted:#687e7b;--cream:#f5f2eb;--paper:#fffefa;--gold:#c49a58;--forest:#124b49;--line:#e3e5dc;--jade:#397a70;--plum:#725d72}
.stApp{background:radial-gradient(ellipse at 90% 0%,rgba(206,183,137,.24),transparent 27%),linear-gradient(180deg,#f8f6f0 0%,#f1f2eb 100%)!important;color:#183c3b!important}
h1,h2,h3,h4{font-family:'Manrope','DM Sans',sans-serif!important;color:#183c3b!important;letter-spacing:-.045em!important}
h1{font-size:clamp(2rem,3.4vw,3rem)!important;line-height:1.12!important}
[data-testid='stSidebar']{background:linear-gradient(165deg,#123d3c 0%,#164f4a 52%,#203f42 100%)!important;border-right:1px solid rgba(220,194,143,.32)!important}
[data-testid='stSidebar'] [data-testid='stRadio'] label{border-radius:14px!important;padding:11px 13px!important;transition:all .22s ease!important;border:1px solid transparent!important}
[data-testid='stSidebar'] [data-testid='stRadio'] label:hover{background:rgba(255,255,255,.09)!important;border-color:rgba(220,194,143,.25)!important;transform:translateX(2px)}
[data-testid='stSidebar'] [data-testid='stRadio'] label[data-checked='true']{background:rgba(220,194,143,.16)!important;border-color:rgba(220,194,143,.48)!important}
[data-testid='stAppViewContainer'] .block-container{padding-top:1.4rem!important;max-width:1320px!important;padding-bottom:4rem!important}
.site-topline{border-bottom:1px solid #dfe4da!important;margin-bottom:15px!important;padding-bottom:12px!important;color:#718582!important}
.site-topline .crumb{color:#286760!important}.site-topline .promise{color:#758884!important}
.hero{border-radius:30px!important;background:radial-gradient(circle at 84% 14%,rgba(220,194,143,.24),transparent 26%),linear-gradient(120deg,#123b3b 0%,#155653 55%,#28776a 100%)!important;border:1px solid rgba(196,154,88,.65)!important;box-shadow:0 24px 60px rgba(24,68,64,.15),inset 0 1px 0 rgba(255,255,255,.12)!important}
.hero h1 span{color:#e6ca91!important}.eyebrow{color:#f2dba8!important;background:rgba(228,199,142,.12)!important;border-color:rgba(228,199,142,.34)!important}
.scard,.panel,.quick-card,.metric,[data-testid='stVerticalBlockBorderWrapper']>div{border-radius:21px!important;box-shadow:0 9px 28px rgba(34,66,60,.055)!important}
.quick-card{background:linear-gradient(145deg,#fffefa,#f2f4eb)!important;border:1px solid #d9e2d8!important;border-top:3px solid #c49a58!important;min-height:155px!important;transition:transform .24s ease,box-shadow .24s ease!important}
.quick-card:hover{transform:translateY(-4px)!important;box-shadow:0 17px 36px rgba(34,66,60,.12)!important}
.quick-icon{background:linear-gradient(145deg,#d9c08d,#f1e3bf)!important;color:#174b49!important;box-shadow:0 5px 13px rgba(164,126,65,.12)!important}
.quick-title{color:#174b49!important}.quick-desc{color:#687d79!important}
.scard,.panel{background:rgba(255,254,250,.94)!important;border-color:#e0e5dc!important}
.pill{background:#e7f2ed!important;color:#2e6c61!important;border-color:#d2e6dd!important}
.metric{background:linear-gradient(145deg,#fffefa,#f0f3eb)!important;border-color:#dfe6dc!important}.num{color:#24675f!important}
.gold-panel{background:linear-gradient(125deg,#e7f0e8,#f3f0e4)!important;border-color:#d2e2d6!important}.gold-kicker{color:#a27b3f!important}
.plan-step{background:#fffefa!important;border-color:#e0e7dd!important;box-shadow:0 4px 14px rgba(34,66,60,.035)!important;transition:transform .2s ease,box-shadow .2s ease!important}.plan-step:hover{transform:translateX(3px);box-shadow:0 8px 20px rgba(34,66,60,.07)!important}.plan-num{background:#dcebe3!important;color:#28675c!important}
/* Every alert follows the palette; no harsh red error panels */
[data-testid='stAlert'],.stAlert,[data-baseweb='notification']{background:#edf3ed!important;border:1px solid #d7e4d8!important;border-radius:15px!important;color:#315d55!important;box-shadow:none!important}
[data-testid='stAlert'] p,.stAlert p,[data-baseweb='notification'] p{color:#315d55!important}
[data-testid='stAlert'][kind='error'],[data-testid='stAlert']:has(svg[aria-label='Error']),.stAlert:has(svg[aria-label='Error']){background:#f1edf2!important;border-color:#e2d8e5!important;color:#67526b!important}
[data-testid='stAlert'][kind='error'] p,.stAlert:has(svg[aria-label='Error']) p{color:#67526b!important}
.stTextInput input,.stNumberInput input,.stTextArea textarea,[data-baseweb='select']>div{border-radius:13px!important;border-color:#d9e1d8!important;background:#fffefa!important;color:#244845!important;min-height:45px!important;transition:border-color .2s,box-shadow .2s!important}
.stTextInput input:focus,.stNumberInput input:focus,.stTextArea textarea:focus{border-color:#6c9b8a!important;box-shadow:0 0 0 3px rgba(83,143,125,.12)!important}
label[data-testid='stWidgetLabel'] p{font-weight:650!important;color:#355c57!important;font-size:.9rem!important}
div.stButton>button{border-radius:14px!important;min-height:2.85rem!important;border:1px solid #d6e0d8!important;background:#fffefa!important;color:#28534d!important;font-weight:700!important;transition:transform .2s,box-shadow .2s,background .2s!important}
div.stButton>button:hover{border-color:#83a99a!important;color:#174b49!important;box-shadow:0 8px 20px rgba(32,87,75,.10)!important;transform:translateY(-1px)!important}
div.stButton>button[kind='primary']{background:linear-gradient(115deg,#175c55,#2e7c6c)!important;border-color:#175c55!important;color:#fffefa!important;box-shadow:0 7px 18px rgba(23,92,85,.13)!important}
div.stButton>button[kind='primary']:hover{background:linear-gradient(115deg,#124b48,#246d60)!important;color:white!important}
[data-testid='stExpander']{background:#fffefa!important;border:1px solid #dfe6dc!important;border-radius:16px!important}
[data-testid='stCheckbox'] label{color:#355c57!important;line-height:1.5!important}
[data-testid='stProgressBar']>div>div{background:linear-gradient(90deg,#c49a58,#397a70)!important}
a{color:#24776b!important}hr{border-color:#e0e5dc!important}
.form-intro{display:flex;align-items:center;gap:16px;background:linear-gradient(115deg,#e5eee6,#f6f0e3);border:1px solid #d8e3d8;border-radius:22px;padding:20px 22px;margin:8px 0 22px;box-shadow:0 8px 25px rgba(30,74,65,.045)}.form-intro-icon{display:flex;align-items:center;justify-content:center;flex:0 0 48px;height:48px;border-radius:16px;background:linear-gradient(140deg,#d9c08d,#f0e2bd);color:#194d49;font-size:1.45rem}.form-intro b{font-family:Manrope,sans-serif;color:#194d49;font-size:1.04rem}.form-intro p{margin:4px 0 0;color:#617773;line-height:1.55;font-size:.91rem}.form-note{background:#eef3eb;border-left:3px solid #c49a58;border-radius:0 13px 13px 0;padding:14px 17px;margin-top:12px;color:#4f6b64;font-size:.91rem;line-height:1.55}.welcome-line{padding:4px 0 14px;color:#345d56;font-size:1.1rem}.welcome-line b{color:#175c55}.welcome-line span{font-size:.9rem;color:#778984}.sidebar-profile{display:flex;align-items:center;gap:11px;padding:12px 11px;margin:8px 0 12px;border-radius:15px;background:rgba(255,255,255,.08);border:1px solid rgba(225,201,151,.22)}.sidebar-avatar{display:flex;align-items:center;justify-content:center;width:37px;height:37px;border-radius:13px;background:linear-gradient(140deg,#d9c08d,#f1e3bf);color:#174b49!important}.sidebar-profile b{display:block;font-size:.88rem;color:#fff!important}.sidebar-profile small{display:block;font-size:.73rem;color:#d2e2db!important;margin-top:3px}
/* Compact journey navigation keeps the user moving forward without returning Home */
.journey-nav{display:flex;gap:8px;align-items:center;margin:2px 0 18px;flex-wrap:wrap}.journey-nav .step{font-size:.78rem;color:#5e7772;background:#eef2ea;border:1px solid #dfe6dc;border-radius:999px;padding:8px 12px}.journey-nav .step.active{background:#dcebe2;border-color:#8bb3a2;color:#175c55;font-weight:800}.journey-nav .connector{height:1px;min-width:12px;flex:1;background:#d7dfd6}
@media(max-width:700px){.form-intro{align-items:flex-start;padding:16px}.form-intro-icon{flex-basis:40px;height:40px}.welcome-line span{display:block;margin-top:5px}.hero{padding:28px 21px!important}}


/* FINAL DESIGN SYSTEM — porcelain, midnight teal, peacock blue and champagne */
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap');
:root{--ink:#172e3b;--muted:#667a83;--paper:#fffdf9;--canvas:#f5f6f2;--navy:#142f43;--teal:#147d80;--teal-deep:#125b62;--mint:#dff1ed;--champagne:#d4b16a;--line:#dfe7e5;--soft-blue:#eaf2f5;--plum:#68566c}
html,body,[class*='css']{font-family:'DM Sans',sans-serif!important}
.stApp{background:radial-gradient(ellipse at 92% 0%,rgba(199,226,220,.72),transparent 28%),radial-gradient(ellipse at 4% 18%,rgba(237,221,189,.28),transparent 25%),linear-gradient(180deg,#fbfaf6 0%,#f2f6f4 100%)!important;color:var(--ink)!important}
h1,h2,h3,h4{font-family:'Playfair Display',serif!important;letter-spacing:-.025em!important;color:var(--navy)!important;font-weight:600!important}
h1{font-size:clamp(2.1rem,3.6vw,3.2rem)!important;line-height:1.12!important}
h2{font-size:clamp(1.55rem,2.5vw,2.15rem)!important}
h3{font-size:1.35rem!important;line-height:1.25!important}
p,li,.stMarkdown,label,.stCaption{font-family:'DM Sans',sans-serif!important}
[data-testid='stAppViewContainer'] .block-container{max-width:1320px!important;padding-top:1.15rem!important;padding-bottom:4rem!important}
[data-testid='stSidebar']{background:linear-gradient(165deg,#122e43 0%,#164b58 54%,#11666a 100%)!important;border-right:1px solid rgba(212,177,106,.38)!important}
[data-testid='stSidebar'] *{font-family:'DM Sans',sans-serif!important}
[data-testid='stSidebar'] [data-testid='stRadio'] label{padding:11px 13px!important;border-radius:14px!important;margin:3px 0!important;border:1px solid transparent!important;transition:background .22s ease,border-color .22s ease,transform .22s ease!important}
[data-testid='stSidebar'] [data-testid='stRadio'] label:hover{background:rgba(255,255,255,.09)!important;border-color:rgba(212,177,106,.28)!important;transform:translateX(2px)}
[data-testid='stSidebar'] [data-testid='stRadio'] label:has(input:checked){background:linear-gradient(110deg,rgba(212,177,106,.2),rgba(255,255,255,.07))!important;border-color:rgba(212,177,106,.45)!important}
[data-testid='stSidebar'] [data-testid='stRadio'] label p{color:#f3f7f5!important;font-weight:600!important;font-size:.91rem!important}
.site-topline{border-bottom:1px solid #dce6e3!important;color:#788992!important;padding-bottom:13px!important;margin-bottom:16px!important;font-size:.79rem!important}
.site-topline .crumb{color:#137579!important;font-weight:800!important}.site-topline .promise{color:#7b8a8f!important}
.hero{border-radius:30px!important;background:radial-gradient(ellipse at 82% 18%,rgba(67,181,174,.34),transparent 29%),radial-gradient(circle at 96% 100%,rgba(212,177,106,.22),transparent 30%),linear-gradient(120deg,#142f43 0%,#155465 55%,#167b7b 100%)!important;border:1px solid rgba(212,177,106,.56)!important;box-shadow:0 25px 62px rgba(20,57,70,.16),inset 0 1px 0 rgba(255,255,255,.13)!important}
.hero h1{font-family:'Playfair Display',serif!important;color:#fffdf7!important;font-size:clamp(2.65rem,4.5vw,4.15rem)!important;line-height:1.04!important;letter-spacing:-.045em!important}
.hero h1 span{color:#f0d89f!important}.hero p{color:#e1efef!important}.eyebrow{color:#f2dba7!important;background:rgba(212,177,106,.13)!important;border-color:rgba(236,208,146,.42)!important}
.hero-tags span{color:#f3f6f3!important;border-color:rgba(230,217,182,.3)!important;background:rgba(255,255,255,.07)!important}.hero-foot{color:#f0d69c!important}
.journey-card{background:linear-gradient(145deg,#fffdf8,#f1f7f3)!important;border-color:rgba(212,177,106,.6)!important;box-shadow:0 22px 48px rgba(0,0,0,.23),inset 0 1px 0 #fff!important}.journey-kicker{color:#9a763d!important}.journey-num{background:#dff1ed!important;color:#126a6c!important}.journey-step b{color:#183b4a!important}.journey-step small{color:#74868a!important}.journey-line{border-color:#cbded9!important}.hero-emblem{background:linear-gradient(145deg,#f4dfad,#d4b16a)!important;color:#163d4b!important}.hero-seal{background:linear-gradient(145deg,#f3e2b8,#d4b16a)!important;color:#163d4b!important;border-color:#e0efeb!important}
.scard,.panel,[data-testid='stVerticalBlockBorderWrapper']>div{background:rgba(255,253,249,.94)!important;border:1px solid #dfe8e5!important;border-radius:22px!important;box-shadow:0 10px 28px rgba(24,60,70,.055)!important}
.scard{padding:23px 24px!important;transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease!important}.scard:hover{transform:translateY(-3px)!important;border-color:#b6d5d0!important;box-shadow:0 17px 34px rgba(24,60,70,.10)!important}
.scard h3{font-family:'Playfair Display',serif!important;color:#17384a!important;font-size:1.45rem!important}.scard p,.muted{color:#6b7e84!important;line-height:1.65!important}
.quick-card{background:linear-gradient(145deg,#fffefa 0%,#edf6f2 100%)!important;border:1px solid #d7e6e2!important;border-top:3px solid var(--champagne)!important;border-radius:20px 20px 0 0!important;min-height:166px!important;box-shadow:0 8px 22px rgba(24,60,70,.05)!important;transition:transform .22s ease,box-shadow .22s ease!important}.quick-card:hover{transform:translateY(-3px)!important;box-shadow:0 16px 32px rgba(24,60,70,.10)!important}.quick-icon{background:linear-gradient(145deg,#d9efea,#b9e0d9)!important;color:#12696b!important;box-shadow:none!important;border:1px solid #c6e4dd!important}.quick-title{font-family:'Plus Jakarta Sans',sans-serif!important;color:#17384a!important;font-weight:800!important}.quick-desc{color:#6d7f84!important}
div[class*='st-key-quick_'] button{background:#e8f3ef!important;border-color:#d7e6e2!important;color:#146b6d!important;border-radius:0 0 18px 18px!important;min-height:2.7rem!important;font-weight:800!important}div[class*='st-key-quick_'] button:hover{background:#d9eeea!important;color:#104e59!important}
.metric{background:linear-gradient(145deg,#fffdf9,#eaf4f2)!important;border:1px solid #dce8e4!important;border-radius:20px!important;box-shadow:0 8px 22px rgba(24,60,70,.045)!important}.num{color:#117477!important;font-family:'Plus Jakarta Sans',sans-serif!important}
.pill{background:#e5f3ef!important;color:#146c6e!important;border:1px solid #d0e8e2!important;font-weight:700!important}.gold-panel,.form-intro{background:linear-gradient(120deg,#e7f3ef,#f9f2e3)!important;border:1px solid #d8e6df!important;border-radius:21px!important}.gold-kicker,.section-kicker{color:#98723a!important;font-family:'Plus Jakarta Sans',sans-serif!important;font-size:.68rem!important;font-weight:800!important;letter-spacing:.12em!important;text-transform:uppercase!important}.gold-panel h3{color:#183b4a!important}
.form-intro{padding:23px 24px!important;box-shadow:0 8px 24px rgba(24,60,70,.04)!important}.form-intro-icon{background:linear-gradient(145deg,#f2dfb2,#d4b16a)!important;color:#163e4c!important;box-shadow:0 7px 18px rgba(157,120,48,.12)!important}.form-intro b{font-family:'Plus Jakarta Sans',sans-serif!important;color:#173b4b!important;font-size:1.05rem!important}.form-intro p{color:#62787d!important}.form-note{background:#eaf4f0!important;border-left:3px solid #d4b16a!important;color:#426a6c!important;border-radius:0 14px 14px 0!important}
/* Form controls: visible labels, comfortable spacing and clear focus states */
[data-testid='stForm']{background:rgba(255,253,249,.84)!important;border:1px solid #dce7e3!important;border-radius:24px!important;padding:25px 25px 20px!important;box-shadow:0 12px 32px rgba(24,60,70,.055)!important}
[data-testid='stWidgetLabel'] p, label{color:#274954!important;font-weight:650!important}
.stTextInput input,.stNumberInput input,.stTextArea textarea,[data-baseweb='select']>div{background:#fffefa!important;color:#193746!important;border:1px solid #d6e3df!important;border-radius:13px!important;min-height:2.85rem!important;box-shadow:inset 0 1px 2px rgba(24,60,70,.025)!important}
.stTextArea textarea{min-height:7rem!important}.stTextInput input:focus,.stNumberInput input:focus,.stTextArea textarea:focus,[data-baseweb='select']>div:focus-within{border-color:#4aada6!important;box-shadow:0 0 0 3px rgba(20,125,128,.13)!important}
[data-testid='stForm'] [data-testid='stFormSubmitButton'] button{min-height:3.15rem!important;font-size:.98rem!important}
div.stButton>button,div[data-testid='stLinkButton'] a{border-radius:13px!important;min-height:2.75rem!important;font-family:'Plus Jakarta Sans',sans-serif!important;font-size:.88rem!important;font-weight:750!important;border:1px solid #d7e5e1!important;background:#fffefa!important;color:#176d70!important;box-shadow:0 4px 12px rgba(24,60,70,.035)!important;transition:all .2s ease!important}
div.stButton>button:hover,div[data-testid='stLinkButton'] a:hover{border-color:#92c8c0!important;background:#eff8f5!important;color:#104f5d!important;transform:translateY(-1px)!important;box-shadow:0 8px 18px rgba(24,60,70,.08)!important}
div.stButton>button[kind='primary'],[data-testid='stFormSubmitButton'] button{background:linear-gradient(115deg,#126b70,#168b87)!important;border:1px solid #126b70!important;color:#fff!important;box-shadow:0 7px 18px rgba(18,107,112,.18)!important}
div.stButton>button[kind='primary']:hover,[data-testid='stFormSubmitButton'] button:hover{background:linear-gradient(115deg,#105c66,#137975)!important;color:#fff!important}
[data-testid='stExpander']{background:rgba(255,253,249,.9)!important;border:1px solid #dfe8e5!important;border-radius:17px!important}.stTabs [data-baseweb='tab-list']{gap:8px}.stTabs [data-baseweb='tab']{border-radius:12px 12px 0 0}
/* No harsh red status indicators: all alert types use this product's palette */
[data-testid='stAlert'],.stAlert,[data-baseweb='notification']{border-radius:15px!important;box-shadow:none!important;background:#edf5f2!important;border:1px solid #d5e7e1!important;color:#285e60!important}
[data-testid='stAlert'] p,.stAlert p,[data-baseweb='notification'] p{color:#285e60!important}
[data-testid='stAlert'] svg,.stAlert svg{color:#368b82!important;fill:#368b82!important}
[data-testid='stAlert'][kind='error'],[data-testid='stAlert'][kind='warning']{background:#fbf3df!important;border-color:#ead8aa!important;color:#735b2e!important}
[data-testid='stAlert'][kind='error'] p,[data-testid='stAlert'][kind='warning'] p{color:#735b2e!important}
[data-testid='stAlert'][kind='error'] svg,[data-testid='stAlert'][kind='warning'] svg{color:#b08b48!important;fill:#b08b48!important}
[data-testid='stAlert'][kind='success']{background:#e8f4eb!important;border-color:#cee4d4!important;color:#2c674b!important}
[data-testid='stAlert'][kind='success'] p{color:#2c674b!important}
[data-testid='stProgressBar']>div>div{background:linear-gradient(90deg,#d4b16a,#2caaa0)!important}
.plan-step{background:#fffefa!important;border-color:#dfe8e5!important;border-radius:16px!important;box-shadow:0 4px 14px rgba(24,60,70,.035)!important}.plan-num{background:#dff1ed!important;color:#126d70!important}
.welcome-line{color:#426b70!important}.welcome-line b{color:#126e71!important}
.journey-nav .step{background:#edf3f0!important;border-color:#dfe8e3!important;color:#61787a!important}.journey-nav .step.active{background:#dff1ed!important;border-color:#80c0b6!important;color:#126d70!important}
.scheme-card-top,.match-card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px}.fit-chip,.match-score{display:flex;flex-direction:column;align-items:center;justify-content:center;flex:0 0 82px;min-height:70px;padding:8px;border:1px solid #d5e9e3;border-radius:17px;background:linear-gradient(145deg,#e5f4ef,#fff7e5);color:#176d70}.fit-chip strong,.match-score strong{font-family:'Plus Jakarta Sans',sans-serif;font-size:1.55rem;line-height:1.1;color:#126f72}.fit-chip span,.match-score span{font-size:.65rem;font-weight:800;letter-spacing:.04em;text-transform:uppercase;color:#74857f;margin-top:4px}.fit-track{height:7px;border-radius:999px;overflow:hidden;background:#e6eeea;margin:13px 0 5px}.fit-track span{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,#d4b16a,#25a69b)}.fit-caption{font-size:.72rem;color:#788b8b;line-height:1.5;margin:5px 0 13px}.scheme-meta{display:grid;grid-template-columns:1fr 1fr;gap:12px;background:#f4f7f3;border:1px solid #e2eae5;border-radius:14px;padding:12px 14px;margin:12px 0}.scheme-meta span{font-size:.84rem;color:#5d7377;line-height:1.55}.scheme-meta b{color:#244a57;font-size:.76rem;letter-spacing:.02em}.match-card-head h3{margin:.35rem 0 .2rem!important}.match-summary{color:#627a7f!important;line-height:1.6!important}
a{color:#147d80!important;font-weight:700!important}hr{border-color:#dfe8e5!important}footer{visibility:hidden}
@media(max-width:900px){.hero{grid-template-columns:1fr!important;padding:32px 26px!important;gap:16px!important}.hero-art{min-height:285px}.scheme-card-top,.match-card-head{align-items:flex-start}.fit-chip,.match-score{flex-basis:72px;min-height:64px}}
@media(max-width:600px){[data-testid='stForm']{padding:16px 14px 13px!important;border-radius:19px!important}.hero{padding:25px 19px!important;border-radius:22px!important}.hero h1{font-size:clamp(2.2rem,9vw,3.1rem)!important}.form-intro{padding:16px!important}.scheme-meta{grid-template-columns:1fr}.fit-chip,.match-score{flex-basis:65px;min-height:60px}.fit-chip strong,.match-score strong{font-size:1.3rem}}


/* Final layout repair: clean responsive hero, visible CTA, and comfortable quick-action cards. */
.hero-clean{display:block!important;min-height:0!important;padding:clamp(28px,4vw,48px)!important;margin:6px 0 14px!important;overflow:hidden!important;position:relative!important;background:radial-gradient(ellipse at 92% 0%,rgba(71,174,157,.28),transparent 34%),linear-gradient(120deg,#123b3b 0%,#155653 58%,#1b716b 100%)!important;}
.hero-clean:after{right:-90px!important;top:-150px!important;width:300px!important;height:300px!important;opacity:.55!important;pointer-events:none!important}
.hero-clean:before{top:28px!important;bottom:28px!important}
.hero-clean .hero-copy{position:relative!important;z-index:1!important;max-width:900px!important;width:100%!important}
.hero-clean h1{font-size:clamp(2.25rem,4.2vw,3.8rem)!important;line-height:1.08!important;letter-spacing:-.045em!important;max-width:100%!important;overflow-wrap:normal!important;word-break:normal!important;margin:20px 0 17px!important}
.hero-clean p{max-width:760px!important;font-size:clamp(.98rem,1.2vw,1.08rem)!important;line-height:1.75!important}
.hero-clean .hero-tags{gap:9px!important;margin-top:22px!important}
.hero-clean .hero-tags span{white-space:normal!important;line-height:1.35!important}
.hero-clean .hero-foot{font-size:.65rem!important;letter-spacing:.1em!important;margin-top:20px!important;overflow-wrap:anywhere!important}
.hero-hint{padding:9px 4px!important;color:#617974!important;font-size:.9rem!important;line-height:1.6!important}
div[class*='st-key-hero_find_schemes'] button{min-height:3.15rem!important;border-radius:14px!important;white-space:normal!important;font-size:.94rem!important;box-shadow:0 8px 20px rgba(18,107,112,.18)!important}
.quick-card{min-height:140px!important;height:auto!important;padding:21px 20px 18px!important;border-radius:18px 18px 0 0!important;overflow-wrap:anywhere!important}
.quick-title{font-size:1.02rem!important;line-height:1.35!important}
.quick-desc{font-size:.87rem!important;line-height:1.55!important;min-height:2.7em!important}
div[class*='st-key-quick_'] button{white-space:normal!important;line-height:1.3!important}
@media(max-width:800px){.hero-clean{padding:29px 24px!important}.hero-clean h1{font-size:clamp(2.15rem,7vw,3.1rem)!important}.hero-clean .hero-foot{letter-spacing:.06em!important}.quick-card{min-height:130px!important}}
@media(max-width:520px){.hero-clean{padding:25px 19px!important;border-radius:22px!important}.hero-clean h1{font-size:2.15rem!important}.hero-clean .hero-tags{display:grid!important;grid-template-columns:1fr!important}.hero-clean .hero-tags span{width:fit-content!important;max-width:100%!important}.hero-clean .hero-foot{font-size:.59rem!important}.quick-card{padding:17px 15px!important}}

/* HARD FIX: prevent hero overflow, invisible first pill, and low-contrast CTA. */
.hero-clean{box-sizing:border-box!important;width:100%!important;max-width:100%!important;min-width:0!important;overflow:hidden!important;padding:clamp(24px,3.2vw,42px)!important;border-radius:28px!important}
.hero-clean .hero-copy{box-sizing:border-box!important;width:100%!important;max-width:100%!important;min-width:0!important}
.hero-clean h1{display:block!important;box-sizing:border-box!important;width:100%!important;max-width:100%!important;min-width:0!important;font-size:clamp(2rem,3.4vw,3.25rem)!important;line-height:1.12!important;letter-spacing:-.035em!important;white-space:normal!important;overflow-wrap:break-word!important;word-break:normal!important;hyphens:auto!important}
.hero-clean h1 span{display:inline!important;color:#f0d89f!important;white-space:normal!important}
.hero-clean p{box-sizing:border-box!important;width:100%!important;max-width:740px!important;overflow-wrap:break-word!important}
.hero-clean .hero-tags{display:flex!important;flex-wrap:wrap!important;gap:8px!important}
.hero-clean .hero-tags span,.hero-clean .hero-tags span:first-child{display:inline-flex!important;align-items:center!important;box-sizing:border-box!important;max-width:100%!important;width:auto!important;padding:8px 11px!important;background:rgba(255,255,255,.09)!important;border:1px solid rgba(240,216,159,.38)!important;border-radius:999px!important;color:#fffaf0!important;font-size:.78rem!important;line-height:1.4!important;white-space:normal!important;overflow-wrap:anywhere!important}
.hero-clean .hero-foot{max-width:100%!important;line-height:1.8!important;letter-spacing:.07em!important;font-size:.65rem!important;overflow-wrap:anywhere!important}
/* Streamlit button internals differ by version; target the real button and its text. */
div[data-testid="stButton"] button,div[data-testid="stFormSubmitButton"] button{box-sizing:border-box!important;min-width:0!important;max-width:100%!important;white-space:normal!important;line-height:1.35!important;font-weight:750!important}
div[data-testid="stButton"] button[kind="primary"],div[data-testid="stButton"] button[data-testid="stBaseButton-primary"],div[data-testid="stFormSubmitButton"] button{background:linear-gradient(120deg,#124b48,#23766a)!important;border:1px solid #124b48!important;color:#fffdf7!important;-webkit-text-fill-color:#fffdf7!important;box-shadow:0 8px 22px rgba(18,75,72,.2)!important}
div[data-testid="stButton"] button[kind="primary"] *,div[data-testid="stButton"] button[data-testid="stBaseButton-primary"] *{color:#fffdf7!important;-webkit-text-fill-color:#fffdf7!important;opacity:1!important}
div[class*="st-key-hero_find_schemes"]{min-width:0!important}
.hero-hint{overflow-wrap:break-word!important}
.quick-card{box-sizing:border-box!important;width:100%!important;min-width:0!important;min-height:130px!important;overflow:hidden!important}
.quick-title,.quick-desc{overflow-wrap:break-word!important;word-break:normal!important}
div[class*="st-key-quick_"] button{color:#174b49!important;-webkit-text-fill-color:#174b49!important;background:#fffdf8!important;border:1px solid #d4e1d8!important}
@media(max-width:900px){.hero-clean{padding:28px 24px!important}.hero-clean h1{font-size:clamp(2rem,5.5vw,2.9rem)!important}}
@media(max-width:600px){.hero-clean{padding:24px 18px!important;border-radius:22px!important}.hero-clean h1{font-size:clamp(1.9rem,8vw,2.4rem)!important;line-height:1.13!important}.hero-clean .hero-tags span,.hero-clean .hero-tags span:first-child{font-size:.75rem!important}.hero-clean .hero-foot{font-size:.58rem!important}.hero-hint{padding:8px 0!important}}

</style>""",unsafe_allow_html=True)
p=profile()
with st.sidebar:
 st.markdown("<div style='padding:9px 0 16px'><div style='font-size:.68rem;letter-spacing:.16em;text-transform:uppercase;color:#d9bd80;font-weight:800'>✦ Citizen support platform</div><div style='font-family:Manrope;font-size:1.55rem;line-height:1.08;font-weight:800;color:#fffdf7;margin-top:9px'>SchemeSense<br><span style='color:#d9bd80'>AI</span></div><div style='font-size:.82rem;color:#d0ded8;margin-top:9px'>A clearer path to public support.</div></div>",unsafe_allow_html=True)
 nav=["Dashboard","My profile","Your Matches","Discover schemes","Recommendations","Eligibility checker","Scheme guide","Funding calculator","Ask SchemeSense AI"]
 nav_labels={"Dashboard":"⌂   Home","My profile":"◉   My profile","Your Matches":"↗   Your Matches","Discover schemes":"⌕   Discover schemes","Recommendations":"✦   For you","Eligibility checker":"✓   Eligibility check","Scheme guide":"▤   Application guide","Funding calculator":"₹   Funding planner","Ask SchemeSense AI":"✧   Ask SchemeSense AI"}
 selected_label=st.radio("YOUR JOURNEY",[nav_labels[x] for x in nav],index=next((i for i,x in enumerate(nav) if x==st.session_state.get('page','Dashboard')),0),label_visibility="visible")
 page=next(x for x in nav if nav_labels[x]==selected_label); st.session_state.page=page
 st.markdown("---")
 if p: st.markdown(f"<div class='sidebar-profile'><span class='sidebar-avatar'>✦</span><div><b>{p.get('name') or 'Your profile'}</b><small>{p.get('purpose','Your support goal')}</small></div></div>",unsafe_allow_html=True)
 with st.expander("Demo profile & local data"):
  st.caption("For classroom demos, you can clear the current profile and progress and enter a completely new person's details. This deletes the saved profile, checklist ticks, tracker notes and chat from this local demo database.")
  if st.button("↻ Start a new demo profile", key="reset_demo_profile", type="primary", use_container_width=True):
   reset_demo_profile(); st.rerun()
  st.caption("Data stays on this computer in schemesense.db. No login or deployment is required.")
 st.caption(f"{len(SCHEMES)} catalogue records · verify official details")
page=st.session_state.page
crumbs={"Dashboard":"Home","My profile":"Your details","Your Matches":"Your matches","Discover schemes":"Explore support","Recommendations":"Personalised options","Eligibility checker":"Check requirements","Scheme guide":"Application journey","Funding calculator":"Plan your support","Ask SchemeSense AI":"Your questions"}
st.markdown(f"<div class='site-topline'><span><span class='crumb'>SchemeSense AI</span> &nbsp; / &nbsp; {crumbs.get(page,page)}</span><span class='promise'>A calmer way to find your next step</span></div>",unsafe_allow_html=True)
flow=[("My profile","01  Your details"),("Your Matches","02  Your matches"),("Scheme guide","03  Application guide"),("Ask SchemeSense AI","04  Ask a question")]
flow_cols=st.columns([1,1,1,1])
for fc,(dest,label) in zip(flow_cols,flow):
 with fc:
  active=(page==dest or (page=="Dashboard" and dest=="My profile" and not p))
  if st.button(label,key="journey_"+dest,use_container_width=True,type="primary" if active else "secondary"):
   st.session_state.page=dest
   if dest=="Scheme guide" and not st.session_state.get("sel") and SCHEMES: st.session_state.sel=SCHEMES[0]["id"]
   st.rerun()
if page=="Dashboard":
 st.markdown("""<section class='hero hero-clean'>
   <div class='hero-copy'>
    <div class='eyebrow'>✦ &nbsp; A PERSONAL GUIDE TO PUBLIC SUPPORT</div>
    <h1>Find your support.<br><span>One step at a time.</span></h1>
    <p>A little clarity can make a big difference. Explore programmes that may fit your situation, understand what to check, and take the next step at your own pace.</p>
    <div class='hero-tags'><span>✦ &nbsp; Personalised discovery</span><span>↗ &nbsp; Official-source links</span><span>✓ &nbsp; Guided preparation</span></div>
    <div class='hero-foot'>EXPLORE AT YOUR PACE &nbsp; · &nbsp; UNDERSTAND YOUR OPTIONS &nbsp; · &nbsp; MOVE FORWARD</div>
   </div>
  </section>""",unsafe_allow_html=True)
 hero_btn, hero_hint = st.columns([1,3])
 with hero_btn:
  if st.button("Find my schemes  →", key="hero_find_schemes", type="primary", use_container_width=True):
   st.session_state.page = "Your Matches" if p else "My profile"
   st.rerun()
 with hero_hint:
  st.markdown("<div class='hero-hint'>Start with your profile to see personalised matches, or explore the catalogue whenever you’re ready.</div>", unsafe_allow_html=True)
 st.markdown("<div style='display:flex;align-items:end;justify-content:space-between;gap:12px;flex-wrap:wrap;margin:10px 0 7px'><div><div style='font-size:.72rem;letter-spacing:.15em;text-transform:uppercase;color:#a47a35;font-weight:850'>YOUR PERSONAL WORKSPACE</div><div style='font-family:Manrope;font-size:1.65rem;font-weight:850;letter-spacing:-.04em;color:#203a33'>Let’s find the right place to start</div></div><div style='font-size:.86rem;color:#68766f'>Pick up wherever you need help</div></div>",unsafe_allow_html=True)
 qa=st.columns(2, gap="large")
 quick_actions=[("⌕","Discover schemes","Browse support by goal, category or keyword","Discover schemes"),("◈","Recommendations","Find options that may fit your profile","Recommendations"),("✓","Eligibility checker","Review key requirements before applying","Eligibility checker"),("₹","Funding calculator","Estimate your savings timeline and explore possible support routes","Funding calculator")]
 for idx,(symbol,title,desc,dest) in enumerate(quick_actions):
  col=qa[idx%2]
  with col:
   st.markdown(f"<div class='quick-card'><div class='quick-icon'>{symbol}</div><div class='quick-title'>{title}</div><div class='quick-desc'>{desc}</div></div>",unsafe_allow_html=True)
   if st.button("Explore →",key="quick_"+dest,use_container_width=True):st.session_state.page=dest;st.rerun()
 if not p:
  st.markdown("<div class='panel'><h2>Start with your profile</h2><p class='muted'>Share broad details and goals. No Aadhaar number or bank credentials needed.</p></div>",unsafe_allow_html=True)
  if st.button("Create my profile →",type="primary"):st.session_state.page="My profile";st.rerun()
 else:
  st.markdown(f"<div class='welcome-line'>Welcome back, <b>{p.get('name') or 'there'}</b> <span>· Your support journey is ready when you are.</span></div>",unsafe_allow_html=True)
  st.subheader("Your workspace"); cols=st.columns(3)
  for c,label,val in zip(cols,["Catalogue records","Potential matches","Your goal"],[len(SCHEMES),sum(status(s,p)=="Potential match" for s in SCHEMES),p.get('purpose','Not set')]):
   with c:st.markdown(f"<div class='metric'><div class='muted'>{label}</div><div class='num'>{val}</div></div>",unsafe_allow_html=True)
  st.subheader("Suggested starting points")
  for s in sorted(SCHEMES,key=lambda x:score(x,p)[0],reverse=True)[:3]:card(s,p)
 st.markdown("### How it works"); a,b,c=st.columns(3)
 for col,n,t,desc in [(a,"01 · TELL US","Build your profile","Share only details needed for discovery."),(b,"02 · DISCOVER","Explore options","See match reasons and what needs checking."),(c,"03 · PREPARE","Apply with confidence","Use official links and checklist guidance.")]:
  with col:st.markdown(f"<div class='panel'><div class='eyebrow' style='color:#267780'>{n}</div><h3>{t}</h3><p class='muted'>{desc}</p></div>",unsafe_allow_html=True)
 st.warning("SchemeSense AI is guidance, not an official eligibility decision. Always confirm current details with the responsible government department.")
elif page=="My profile":
 st.title("Let’s get to know you"); st.write("A few details help us make your next steps feel personal and relevant.")
 st.markdown("<div class='form-intro'><span class='form-intro-icon'>✦</span><div><b>Your profile, your pathway</b><p>Save your details once. We’ll use them to organise relevant options and guide you through what to check next.</p></div></div>",unsafe_allow_html=True)
 states=["Tamil Nadu","Andhra Pradesh","Karnataka","Kerala","Telangana","Maharashtra","Delhi","Uttar Pradesh","West Bengal","Other"]
 goals=["Education and scholarships","Starting or expanding a business","Employment and skill development","Agriculture and farming","Women’s welfare and empowerment","Housing","Healthcare","Pension and social security","Financial assistance","Livelihood support","Disability-related assistance","Other welfare needs"]
 occs=["Student","Unemployed","Employed","Self-employed","Entrepreneur","Farmer","Agricultural worker","Homemaker","Artisan","Person with a disability","Senior citizen","Other"]
 edus=["School","Higher secondary","Diploma","Undergraduate","Postgraduate","Any","No formal education"]
 with st.form("profile"):
  name=st.text_input("Full name *",p.get("name") or "",placeholder="Enter your name")
  a,b,c=st.columns(3)
  with a: age=st.number_input("Age *",0,120,int(p.get('age') or 18)); state=st.selectbox("State *",states,index=states.index(p.get('state')) if p.get('state') in states else 0); district=st.text_input("District",p.get('district') or "")
  with b: education=st.selectbox("Education",edus,index=edus.index(p.get('education')) if p.get('education') in edus else 0); occupation=st.selectbox("Occupation *",occs,index=occs.index(p.get('occupation')) if p.get('occupation') in occs else 0); income=st.number_input("Annual household income (₹, optional)",0,100000000,int(p.get('income') or 0),step=10000)
  with c: category=st.selectbox("Eligibility category (optional)",["Prefer not to say","SC","ST","OBC","EWS","Minority","Person with disability","Other"],index=(["Prefer not to say","SC","ST","OBC","EWS","Minority","Person with disability","Other"].index(p.get("category")) if p.get("category") in ["SC","ST","OBC","EWS","Minority","Person with disability","Other"] else 0)); residence=st.selectbox("Residence",["Rural","Urban","Not sure"],index=(["Rural","Urban","Not sure"].index(p.get("residence")) if p.get("residence") in ["Rural","Urban","Not sure"] else 0)); language=st.selectbox("Preferred language",["English","Tamil"],index=(["English","Tamil"].index(p.get("language")) if p.get("language") in ["English","Tamil"] else 0))
  purpose=st.selectbox("What would you like support with? *",goals,index=goals.index(p.get('purpose')) if p.get('purpose') in goals else 0); target=st.number_input("Financial target (₹, optional)",0,100000000,int(p.get('target') or 0),step=5000)
  if st.form_submit_button("Save profile",type="primary",use_container_width=True):
   if not name.strip():st.error("Please enter your name so we can personalise your journey.")
   elif age<1:st.error("Enter a valid age.")
   else:save(dict(name=name.strip(),age=age,state=state,district=district,education=education,occupation=occupation,income=income or None,category=None if category=="Prefer not to say" else category,residence=residence,purpose=purpose,language=language,target=target or None,notes=""));st.session_state.page="Your Matches";st.session_state.flow_step=2;st.session_state.matches_fresh=True;st.rerun()
 st.caption("Your profile is stored locally on this device. Never enter Aadhaar numbers, passwords or full bank details.")
 st.markdown("<div class='form-note'>Next up: we’ll organise possible matches for your goal, then guide you through the application journey.</div>",unsafe_allow_html=True)
elif page=="Your Matches":
 st.title(f"Your matches, {p.get('name') or 'friend'}" if p else "Your personalised matches")
 if not p:
  st.info("Save your profile first. SchemeSense will use your broad details and goal to prioritise relevant programmes.")
  if st.button("Create my profile",type="primary"): st.session_state.page="My profile"; st.rerun()
 else:
  st.markdown(f"<div class='gold-panel'><div class='gold-kicker'>YOUR PROFILE</div><h3>{p.get('name','Your goal')} · {p.get('purpose','Your goal')}</h3><p style='color:#c7c0b1'>{p.get('state','')} · {p.get('occupation','')} · {p.get('education','')}</p></div>",unsafe_allow_html=True)
  st.markdown("<div class='form-note'>Your profile is saved. Start here: these are the closest catalogue matches for your goal and location. Open a guide to continue into documents, application steps and tracking.</div>",unsafe_allow_html=True)
  st.caption("These are preliminary leads, not confirmed eligibility. The official notice determines who qualifies, which documents are required, and the actual deadline.")
  matches=sorted(SCHEMES,key=lambda x:(fit_percentage(x,p),score(x,p)[0],x.get('purpose')==p.get('purpose')),reverse=True)
  matches=[x for x in matches if x.get('state') in ('All India',p.get('state')) and (x.get('purpose')==p.get('purpose') or x.get('occupation') in (p.get('occupation'),'Other') or score(x,p)[0]>=4)]
  if not matches:
   matches=sorted([x for x in SCHEMES if x.get('state') in ('All India',p.get('state'))],key=lambda x:(fit_percentage(x,p),score(x,p)[0]),reverse=True)
  if not matches: st.info("No strong catalogue match found. Use Discover schemes or ask the assistant to explore another route.")
  for idx,s in enumerate(matches[:8],1):
   n,why=score(s,p)
   with st.container(border=True):
    fit=fit_percentage(s,p)
    st.markdown(f"<div class='authority-badge'>{government_label(s)}</div><div class='match-card-head'><div><div class='section-kicker'>YOUR MATCH #{idx:02d} · {s['level'].upper()} · {s['category'].upper()}</div><h3>{s['name']}</h3></div><div class='match-score'><strong>{fit}%</strong><span>profile fit</span></div></div><p class='match-summary'>{s['summary']}</p><div class='fit-track'><span style='width:{fit}%'></span></div><div class='fit-caption'>Ranked by how closely the catalogue tags align with your profile — not a guarantee of eligibility.</div>",unsafe_allow_html=True)
    c1,c2=st.columns([1,1])
    with c1:
     st.write("**Why it appeared**")
     for reason in profile_reasons(s,p)[:3]: st.write("• "+reason)
     st.write("**Deadline:** Not live-verified — open the official notice.")
    with c2:
     st.write("**Your next steps**")
     st.markdown("1. Confirm this exact scheme and current application window.\n2. Compare the full eligibility rules with your profile.\n3. Check the official document list.\n4. Apply only through the official route and save acknowledgement.")
    if st.button("Open full guide & checklist →",key="plan_"+s['id'],type="primary",use_container_width=True): st.session_state.sel=s['id'];st.session_state.page="Scheme guide";st.rerun()
  st.divider()
  nav1,nav2=st.columns(2)
  with nav1:
   if st.button("← Edit my profile",use_container_width=True):st.session_state.page="My profile";st.rerun()
  with nav2:
   if st.button("Continue to ask the AI →",type="primary",use_container_width=True): st.session_state.page="Ask SchemeSense AI";st.rerun()
elif page=="Discover schemes":
 st.title("Discover schemes")
 st.write("Browse by the kind of support you need, then open a scheme to see its guide and official department source.")
 families=["All categories"]+sorted({scheme_family(x) for x in SCHEMES})
 family_cols=st.columns(5)
 family_short=[("🎓","Scholarships & Education"),("🌾","Agriculture & Farmers"),("🐟","Fisheries & Coastal Livelihoods"),("🧰","Business & Self-employment"),("🩺","Health & Disability Support"),("👩","Women & Family"),("🧓","Pensions & Social Security"),("🏠","Housing & Essential Services"),("🛠️","Employment & Worker Welfare"),("🏛️","Citizen Services & Other Support")]
 st.markdown("<div class='category-guide'>Choose a category to filter the catalogue. Categories are based on scheme titles and catalogue tags; confirm the exact component on the official source.</div>",unsafe_allow_html=True)
 selected_family=st.selectbox("Browse by support category",families,key="discover_family")
 a,b,c=st.columns([1.5,1,1])
 with a:q=st.text_input("Search name or keyword",placeholder="scholarship, farmer, fisher, pension…")
 with b:level=st.selectbox("Government coverage",["All","Central","State"])
 with c:category=st.selectbox("Catalogue category",["All"]+sorted(set(s['category'] for s in SCHEMES)))
 d,e=st.columns(2)
 with d:purpose=st.selectbox("Purpose",["All"]+sorted(set(s['purpose'] for s in SCHEMES)))
 with e:sort=st.selectbox("Sort results",["Best match first","Name A–Z"])
 results=[]
 for s in SCHEMES:
  blob=(s['name']+' '+s['summary']+' '+s['eligibility']+' '+s['category']+' '+s['purpose']+' '+s['benefit_type']).lower()
  if q and q.lower() not in blob:continue
  if level!='All' and s['level']!=level:continue
  if category!='All' and s['category']!=category:continue
  if purpose!='All' and s['purpose']!=purpose:continue
  if selected_family!="All categories" and scheme_family(s)!=selected_family:continue
  results.append(s)
 if sort=="Best match first": results.sort(key=lambda x:(fit_percentage(x,p),score(x,p)[0]),reverse=True)
 else: results.sort(key=lambda x:x['name'].lower())
 st.caption(f"{len(results)} schemes/services · results are catalogue leads, not confirmed eligibility")
 if not results:st.info("No results in this category with the current filters. Try clearing a filter or choosing another category.")
 for s in results:
  st.markdown(f"<div class='authority-badge'>{government_label(s)}</div>",unsafe_allow_html=True)
  card(s,p)
elif page=="Recommendations":
 st.title("Recommended for you")
 if not p:
  st.info("Complete your profile first.")
  if st.button("Complete profile"):st.session_state.page="My profile";st.rerun()
 else:
  st.markdown(f"<div class='panel'><h3>{p.get('purpose')}</h3><p class='muted'>{p.get('state')} · {p.get('occupation')} · {p.get('education')} · income {'provided' if p.get('income') else 'not provided'}</p></div>",unsafe_allow_html=True)
  st.caption("Transparent rule-based ranking; not a generative AI model or official eligibility decision.")
  for s in sorted(SCHEMES,key=lambda x:(fit_percentage(x,p),score(x,p)[0]),reverse=True)[:25]:
   n,why=score(s,p); fit=fit_percentage(s,p)
   with st.expander(f"{fit}% fit · {s['name']} · {status(s,p)}"):
    st.write(s['summary']);st.write("**Why surfaced**");[st.write("• "+x) for x in why];st.write("**Still verify:** active status, full eligibility, documents, deadline and benefit terms.")
    if st.button("Open guide",key="rec"+s['id']):st.session_state.sel=s['id'];st.session_state.page="Scheme guide";st.rerun()
elif page=="Eligibility checker":
 st.title("Eligibility checker"); sid=st.selectbox("Select a programme",[s['id'] for s in SCHEMES],format_func=lambda x:next(s['name'] for s in SCHEMES if s['id']==x));s=next(s for s in SCHEMES if s['id']==sid)
 st.subheader(s['name']);st.write(s['eligibility'])
 if p:
  st.markdown(f"### Preliminary result: **{status(s,p)}**")
  for label,ok in [("State",s['state']=='All India' or s['state']==p.get('state')),("Goal",s['purpose']==p.get('purpose')),("Occupation",s['occupation']==p.get('occupation') or s['occupation']=='Other')]:st.write(("✅ " if ok else "🔎 ")+label+(" appears aligned" if ok else " needs confirmation"))
 st.warning("Some conditions are not represented here. Only the responsible authority can confirm eligibility.")
 if st.button("Open full guide",type="primary"):st.session_state.sel=sid;st.session_state.page="Scheme guide";st.rerun()
elif page=="Scheme guide":
 st.markdown("<div class='form-note'>Your journey continues here: review the route, prepare only the documents the official notice asks for, then track your application.</div>",unsafe_allow_html=True)
 sid=st.selectbox("Choose a scheme",[s['id'] for s in SCHEMES],index=next((i for i,s in enumerate(SCHEMES) if s['id']==st.session_state.get('sel')),0),format_func=lambda x:next(s['name'] for s in SCHEMES if s['id']==x));st.session_state.sel=sid;guide(next(s for s in SCHEMES if s['id']==sid),p)
elif page=="Funding calculator":
 st.title("Funding & support planner")
 st.write("Work out the size of your funding gap, what a monthly saving plan could look like, and which scheme routes may be worth checking. Scheme benefits are not assumed or added together unless official rules confirm them.")
 if p:
  st.markdown(f"<div class='panel'><b>Personalised for {p.get('name') or 'you'}</b><p class='muted' style='margin-bottom:0'>{p.get('purpose','Your support goal')} · {p.get('state','State not set')} · Your saved profile is used as the starting point.</p></div>",unsafe_allow_html=True)
 a,b=st.columns(2)
 with a:
  target=st.number_input("Total amount you need (₹)",min_value=0,max_value=100000000,value=int((p or {}).get('target') or 75000),step=5000,key="fund_target")
  savings=st.number_input("Amount already saved / available (₹)",min_value=0,max_value=100000000,value=0,step=1000,key="fund_savings")
  monthly=st.number_input("Amount you can set aside each month (₹)",min_value=0,max_value=10000000,value=3000,step=500,key="fund_monthly")
 with b:
  timeline=st.selectbox("When do you need the amount?",[3,6,9,12,18,24,36],index=3,format_func=lambda x:f"Within {x} months",key="fund_timeline")
  goals=["Education and scholarships","Starting or expanding a business","Employment and skill development","Agriculture and farming","Women’s welfare and empowerment","Housing","Healthcare","Pension and social security","Financial assistance","Livelihood support","Disability-related assistance","Other welfare needs"]
  default_goal=(p or {}).get('purpose')
  goal_idx=goals.index(default_goal) if default_goal in goals else 0
  purpose=st.selectbox("What is the funding for?",goals,index=goal_idx,key="fund_purpose")
  states=["Tamil Nadu","Andhra Pradesh","Karnataka","Kerala","Telangana","Maharashtra","Delhi","Uttar Pradesh","West Bengal","Other"]
  default_state=(p or {}).get('state')
  state_idx=states.index(default_state) if default_state in states else 0
  state=st.selectbox("State",states,index=state_idx,key="fund_state")
 if st.button("Calculate my plan & find schemes",type="primary",use_container_width=True):
  gap=max(int(target)-int(savings),0)
  required=(gap+int(timeline)-1)//int(timeline) if timeline else gap
  months_needed=((gap+int(monthly)-1)//int(monthly)) if monthly>0 and gap>0 else (0 if gap==0 else None)
  pp=dict(p or {});pp.update(purpose=purpose,state=state)
  local=[x for x in SCHEMES if x.get('state') in ('All India',state)]
  exact=[x for x in local if x.get('purpose')==purpose]
  if not exact:
   related={
    'Education and scholarships':['Education','Student'],
    'Starting or expanding a business':['Business','Entrepreneur'],
    'Employment and skill development':['Employment','Worker Welfare','Business'],
    'Agriculture and farming':['Agriculture','Farmer'],
    'Women’s welfare and empowerment':['Women & Family'],
    'Housing':['Housing','Rural Development'],
    'Healthcare':['Healthcare'],
    'Pension and social security':['Pension & Social Security','Worker Welfare'],
    'Financial assistance':['Business','Education','Energy & Household','Women & Family'],
    'Livelihood support':['Worker Welfare','Business','Agriculture'],
    'Disability-related assistance':['Disability'],
    'Other welfare needs':['Public Services','Food & Household','Rural Development']}
   keys=related.get(purpose,[])
   exact=[x for x in local if any(k.lower() in (x.get('category','')+' '+x.get('name','')+' '+x.get('benefit_type','')).lower() for k in keys)]
  exact.sort(key=lambda x:(fit_percentage(x,pp),score(x,pp)[0],x.get('purpose')==purpose),reverse=True)
  st.session_state.funding_result={'target':int(target),'savings':int(savings),'monthly':int(monthly),'timeline':int(timeline),'gap':gap,'required':required,'months_needed':months_needed,'purpose':purpose,'state':state,'scheme_ids':[x['id'] for x in exact[:8]]}
 result=st.session_state.get('funding_result')
 if result:
  gap=result['gap']; required=result['required']; monthly_now=result['monthly']; months_needed=result['months_needed']; timeline_now=result['timeline']
  st.markdown("### Your funding picture")
  m1,m2,m3=st.columns(3)
  with m1: st.markdown(f"<div class='metric'><div class='muted'>Amount still needed</div><div class='num'>₹{gap:,.0f}</div><div class='muted'>Target minus savings</div></div>",unsafe_allow_html=True)
  with m2: st.markdown(f"<div class='metric'><div class='muted'>Monthly amount for your timeline</div><div class='num'>₹{required:,.0f}</div><div class='muted'>To reach the target in {timeline_now} months</div></div>",unsafe_allow_html=True)
  with m3:
   if gap==0: timeline_text="Target already covered"
   elif months_needed is None: timeline_text="Add monthly capacity"
   else: timeline_text=f"About {months_needed} month{'s' if months_needed!=1 else ''}"
   st.markdown(f"<div class='metric'><div class='muted'>At your monthly capacity</div><div class='num' style='font-size:1.45rem'>{timeline_text}</div><div class='muted'>₹{monthly_now:,.0f} per month, before interest or changing costs</div></div>",unsafe_allow_html=True)
  if gap==0: st.success("Based on the amounts entered, your savings cover the target.")
  elif monthly_now==0: st.info(f"You still need ₹{gap:,.0f}. Enter a monthly amount to estimate a saving timeline.")
  elif monthly_now<required: st.warning(f"At ₹{monthly_now:,.0f}/month, you would need about {months_needed} months. To meet your {timeline_now}-month timeline, the monthly plan is short by ₹{required-monthly_now:,.0f}.")
  else: st.success(f"At ₹{monthly_now:,.0f}/month, you could reach the remaining target in about {months_needed} months, assuming no change in costs or savings.")
  st.markdown("### Scheme routes worth checking")
  ids=result.get('scheme_ids',[]); scheme_lookup={x['id']:x for x in SCHEMES}; route_schemes=[scheme_lookup[sid] for sid in ids if sid in scheme_lookup]
  if not route_schemes:
   st.info("No close match was found in the starter catalogue for this goal and state. Try Discover schemes or ask SchemeSense AI. This does not mean that no government support exists.")
  for idx,s in enumerate(route_schemes,1):
   n,why=score(s,dict(p or {},purpose=result['purpose'],state=result['state']))
   with st.container(border=True):
    st.markdown(f"<div class='match-card-head'><div><div class='section-kicker'>ROUTE {idx:02d} · {s['level'].upper()} · {s['category'].upper()}</div><h3>{s['name']}</h3></div><div class='match-score'><strong>{fit_percentage(s,dict(p or {},purpose=result['purpose'],state=result['state']))}%</strong><span>profile fit</span></div></div><p class='match-summary'>{s['summary']}</p><div class='fit-caption'>Catalogue alignment only; verify the official rules.</div>",unsafe_allow_html=True)
    st.write(f"**Type of support:** {s['benefit_type']}")
    st.write(f"**Amount / terms:** {s['amount']}")
    st.caption("This planner does not estimate a government benefit amount or combine schemes. Confirm whether the programme is active, whether you qualify, and whether its support can cover your specific cost.")
    ca,cb=st.columns(2)
    with ca:
     if st.button("Open application guide →",key="fundguide_"+s['id'],type="primary",use_container_width=True): st.session_state.sel=s['id'];st.session_state.page="Scheme guide";st.rerun()
    with cb: st.link_button("Check official source ↗",s['url'],use_container_width=True)
  st.markdown("<div class='form-note'><b>How to use this result:</b> treat the saving estimate as arithmetic, not financial advice. Treat the scheme list as leads to verify. Loans need repayment; insurance, services and in-kind support are not necessarily cash. Do not assume multiple benefits can be combined.</div>",unsafe_allow_html=True)
elif page=="Ask SchemeSense AI":
 st.title("Ask SchemeSense AI");st.write("Ask general questions, compare options, understand eligibility, documents, deadlines and application steps. With an OpenAI API key, the assistant can answer broader questions conversationally; without one, it uses a limited catalogue-grounded fallback.")
 api=os.getenv("OPENAI_API_KEY");st.caption("Mode: "+("AI assistant connected" if api else "Basic offline-style catalogue fallback — add an OpenAI API key for broad conversational answers"))
 if not api: st.info("For a genuinely conversational AI assistant, add OPENAI_API_KEY in your terminal as described in README.md. Keep the key private; API usage may incur charges.")
 if 'chat' not in st.session_state:st.session_state.chat=[]
 st.markdown("### Choose a question to get started")
 st.caption("Tap a suggested question or type your own below. Answers are personalised using your saved profile and the scheme catalogue; current rules still need official verification.")
 prompts=[
  "Which schemes may suit my profile?", "How do I apply for a scholarship?", "What documents should I prepare?",
  "How can a farmer find current support?", "What support may be available to fishermen?", "How do I check a scheme's last date?",
  "What help is available for starting a small business?", "How can I check pension eligibility?", "What support may help with healthcare?",
  "How do I apply for disability-related support?", "How can I track an application after submitting it?", "Explain the difference between a grant and a loan.",
  "How can I find Tamil Nadu government schemes?", "What should I do if I am missing a document?", "How do I avoid fake scheme websites?", "Explain the application process in simple Tamil."
 ]
 for row_start in range(0,len(prompts),4):
  prompt_cols=st.columns(4)
  for col,question in zip(prompt_cols,prompts[row_start:row_start+4]):
   with col:
    if st.button(question,key="prompt_"+str(prompts.index(question)),use_container_width=True):
     st.session_state.pending_question=question; st.rerun()
 for m in st.session_state.chat:
  with st.chat_message(m['role']):st.markdown(m['content'])
 typed_q=st.chat_input("Ask anything about schemes, documents, deadlines or next steps… / கேள்வி கேளுங்கள்…")
 q=st.session_state.pop("pending_question",None) or typed_q
 if q:
  st.session_state.chat.append({'role':'user','content':q})
  with st.chat_message('user'):st.write(q)
  toks=set(re.findall(r'[a-zA-Z]{3,}',q.lower())); ranked=[]
  for s in SCHEMES:
   text=(s['name']+' '+s['summary']+' '+s['category']+' '+s['purpose']+' '+s['eligibility']).lower(); n=sum(t in text for t in toks)
   if n:ranked.append((n,s))
  ranked.sort(key=lambda x:x[0],reverse=True); ranked=ranked[:4]
  answer=''
  if api:
   try:
    from openai import OpenAI
    # Add profile-relevant schemes even when the user's wording does not match catalogue terms.
    by_id={s['id']:s for _,s in ranked}
    if p:
     for s in sorted(SCHEMES,key=lambda x:score(x,p)[0],reverse=True)[:5]: by_id.setdefault(s['id'],s)
    context_schemes=list(by_id.values())[:8]
    ctx='\n'.join(f"{s['name']} [{s['level']} / {s['state']}]: {s['summary']} Eligibility notes: {s['eligibility']} Support: {s['benefit_type']}; amount: {s['amount']}. Preparation prompts: {', '.join(possible_documents(s,p)[:7])}. General steps: {'; '.join(s['steps'])}. Official starting point: {s['url']}." for s in context_schemes)
    history=[{'role':m['role'],'content':m['content']} for m in st.session_state.chat[-8:] if m.get('role') in ('user','assistant')]
    system='You are SchemeSense AI, a careful and empathetic guide to Indian government schemes and public services. Answer general questions too, not only scheme-name searches. Give practical, numbered next steps, explain jargon simply, and personalise only using the supplied profile. Use the supplied catalogue as a starter catalogue, not an authoritative live database. Never invent deadlines, required documents, eligibility rules, benefit amounts, application statuses or URLs. If a fact is missing, explicitly say it must be checked in the latest official notice and give the official starting link if supplied. Clearly distinguish general preparation prompts from mandatory documents. Do not guarantee eligibility, approval or payment. Explain that loans must be repaid. Do not ask for Aadhaar numbers, passwords, bank account numbers or other sensitive secrets. Answer in Tamil if asked or if the profile language is Tamil.'
    messages=[{'role':'system','content':system},{'role':'system','content':f"User profile (may be empty; use their name naturally but not in every sentence): {p}\nRelevant catalogue context: {ctx}\nUse these facts carefully."}]+history
    response=OpenAI(api_key=api).chat.completions.create(model=os.getenv('OPENAI_MODEL','gpt-4o-mini'),temperature=.2,messages=messages);answer='**AI-assisted guidance — verify official details.**\n\n'+response.choices[0].message.content
   except Exception:answer='The optional AI API could not be reached; using catalogue fallback.\n\n'
  if not answer or 'fallback' in answer:
   answer="**Here is a practical starting point**\n\n"
   qlow=q.lower()
   topic_hints={
    "scholarship":("Education and scholarships",["Confirm course and academic year eligibility.","Check the institution and current scholarship notice for marks, income and category rules.","Ask whether your college must verify or forward the application.","Submit through the official portal before the published closing date."]),
    "student":("Education and scholarships",["Confirm course, institution and academic year.","Check the scholarship notice and college deadline.","Prepare marksheets, bonafide/admission and fee details only if requested."]),
    "farmer":("Agriculture and farming",["Choose the exact agriculture component (equipment, irrigation, crop, insurance or credit).","Check current state/district availability and farmer registration rules.","Use the state agriculture department or official scheme portal; check application window and approved vendors if relevant."]),
    "agriculture":("Agriculture and farming",["Identify the crop/activity and exact programme component.","Check land/farmer registration conditions and district availability.","Use the official agriculture department channel and keep the acknowledgement."]),
    "fisher":("Livelihood support",["Check the Fisheries Department or relevant fishermen welfare board for your state.","Confirm whether the benefit is for active fishers, boat/gear owners, registered workers, or a specific season.","Verify registration, required records and the current application window with the department."]),
    "business":("Starting or expanding a business",["Decide whether you need a grant, subsidy, loan, training or registration service.","Prepare a basic project cost estimate and business plan if required.","Use the official department or participating lender and review interest/repayment before accepting a loan."]),
    "pension":("Pension and social security",["Identify the pension component and whether it is contributory or means-tested.","Check age, income, occupation and exclusion rules.","Use the official portal or notified local service centre and save the acknowledgement."]),
    "health":("Healthcare",["Check whether the scheme covers your household and the treatment/service needed.","Verify the beneficiary list, covered hospitals, exclusions and pre-authorisation rules.","Confirm with the authorised hospital or official helpline before relying on coverage."]),
    "disability":("Disability-related assistance",["Check whether you need certification/UDID or a separate financial/education benefit.","Confirm the official assessment and document process.","Check separate scheme eligibility after certification; certification alone may not provide cash assistance."]),
    "deadline":("",["Open the official scheme page and locate the latest notice for the exact component and year.","Look for application opening date, last date, renewal date, and any institution/district cut-off.","If no date is published, contact the implementing department; this demo catalogue does not contain verified live deadlines."]),
    "last date":("",["Open the official scheme page and locate the latest notice for the exact component and year.","Look for application opening date, last date, renewal date, and any institution/district cut-off.","Do not rely on an old notice or an unofficial website; this demo cannot verify live dates."]),
    "loan":("",["A grant generally does not need repayment if its terms are met; a loan must be repaid with applicable interest.","Subsidies may be conditional and may be routed through a lender or vendor.","Read the official sanction, interest, repayment and exclusion terms before accepting support."]),
    "fake":("",["Start from a .gov.in domain or a department website linked from an official government portal.","Never pay an agent who guarantees approval; verify fees in the official notice.","Do not share Aadhaar OTPs, passwords, PINs or full bank credentials in chat."])
   }
   chosen=None
   for key,val in topic_hints.items():
    if key in qlow: chosen=val; break
   if chosen:
    topic,steps=chosen
    answer+="\n".join(f"{i}. {step}" for i,step in enumerate(steps,1))+"\n\n"
   elif p:
    answer+=f"Based on your saved profile, {p.get('name') or 'you'} are looking for **{p.get('purpose','public support')}** in **{p.get('state','your state')}** as **{p.get('occupation','your beneficiary group')}**. I can give a more exact route if you choose a topic above.\n\n"
   if ranked:
    answer+="**Relevant catalogue starting points**\n\n"
    for _,sch in ranked[:4]:answer+=f"**{sch['name']}** — {sch['summary']}\n- Listed coverage: {sch['state']} · {sch['category']}\n- Support: {sch['benefit_type']}\n- Official starting point: {sch['url']}\n\n"
   elif p:
    relevant=sorted(SCHEMES,key=lambda sch:(fit_percentage(sch,p),score(sch,p)[0]),reverse=True)[:3]
    answer+="**A few catalogue leads based on your profile**\n\n"
    for sch in relevant:answer+=f"**{sch['name']}** — {sch['summary']}\n- Listed coverage: {sch['state']} · {sch['category']}\n- Official starting point: {sch['url']}\n\n"
   else:
    answer+="Tell me your broad goal (for example, education, farming, fisheries, healthcare, pension or business) and your state. Do not share Aadhaar numbers, OTPs or bank credentials.\n\n"
   answer+="**Important:** I can explain the process and help you prepare, but current eligibility, required documents and dates must be confirmed in the latest official notice. I will say when the catalogue does not contain a verified fact rather than inventing one."
   if p and p.get('language')=='Tamil':answer+='\n\nதற்போதைய தகுதி, ஆவணங்கள் மற்றும் விண்ணப்ப தேதிகளை அதிகாரப்பூர்வ அறிவிப்பில் உறுதிப்படுத்தவும்.'
  st.session_state.chat.append({'role':'assistant','content':answer})
  with st.chat_message('assistant'):st.markdown(answer)
 if st.button("Clear conversation"):st.session_state.chat=[];st.rerun()
st.markdown("---");st.caption(f"SchemeSense AI · {len(SCHEMES)} catalogue records · personal guidance · verify scheme details with official sources")
